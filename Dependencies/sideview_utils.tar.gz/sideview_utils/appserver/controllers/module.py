#Copyright (C) 2010-2015 Sideview LLC.  All Rights Reserved. 

import logging, cherrypy
import splunk.appserver.mrsparkle.controllers as controllers
from splunk.appserver.mrsparkle.lib.decorators import expose_page
from lib.module import moduleMapper

import sideview as sv

logger = logging.getLogger('splunk.appserver.controllers.module')


# URL: /custom/sideview_utils/module/show
class module(controllers.BaseController):

    @expose_page(must_login=True, methods=['GET']) 
    def add_new(self, view, app, successMessage=None, **kwargs) : 
        definitions = moduleMapper.getInstalledModules()
        classNames = definitions.keys()
        classNames.sort()

        moduleClasses = []
        for moduleClass in classNames: 
            if (moduleClass in sv.abstractModules or moduleClass.find('Abstract') > -1) : 
                continue
            if (moduleClass in sv.unusualModules) : 
                continue
            moduleClasses.append({
                "label" : moduleClass.replace("Splunk.Module.",""),
                "class" : moduleClass
            })

        return self.render_template("/sideview_utils:/templates/choose_module_to_add.html", {
            "moduleClasses" : moduleClasses, 
            "app":app,
            "view":view, 
            "successMessage" : successMessage,
            "base_url" : self.make_url("/static/app/sideview_utils/")
        })


    @expose_page(must_login=True, methods=['GET']) 
    def reattach_existing(self, view, app, successMessage=None, **kwargs) : 
        return self.render_template("/sideview_utils:/templates/choose_module_to_reattach.html", {
            "app":app,
            "view":view, 
            "successMessage" : successMessage,
            "base_url" : self.make_url("/static/app/sideview_utils/")
        })


    @expose_page(must_login=True, methods=['GET']) 
    def choose_existing(self, view, app, successMessage=None,**kwargs):
        action = kwargs.get("action","edit")
        if (action=="edit") :
            template = "choose_node_to_edit.html"
        elif (action=="delete") :
            template = "choose_node_to_delete.html"
        elif (action=="debug") :
            template = "choose_node_to_debug.html"

        return self.render_template("/sideview_utils:/templates/" + template, {
            "app":app,
            "view":view, 
            "successMessage" : successMessage,
            "base_url" : self.make_url("/static/app/sideview_utils/")
        })


    @expose_page(must_login=True, methods=['GET']) 
    def edit(self, moduleClass, moduleId, view, app,**kwargs):
        
        # we avoid using optional args to avoid the buggy exception handling.
        parentModuleId=kwargs.get("parentModuleId",None) 
        insertBeforeModuleId=kwargs.get("insertBeforeModuleId",None) 
        parentModuleClass=kwargs.get("parentModuleClass",None) 

        if (parentModuleClass=="view") :
            parentModuleId = "_top"

        definitions = moduleMapper.getInstalledModules()

        moduleAttributes = ["layoutPanel","autoRun","group"]
        moduleAttributeMap = {}
            
        currentParamValues = {}
        if (moduleId=="_new") :
            if (parentModuleId!="_top") :
                for attName in moduleAttributes: 
                    val, inheritedVal = sv.getAttributeValueForModule(app, view, parentModuleId, attName)

                    # NB: to see things from the child's perspective, we set BOTH to the the raw val. 
                    moduleAttributeMap[attName] = {
                        "value":val,
                        "inheritedValue":val
                    }
            else :
                for attName in moduleAttributes: 
                    moduleAttributeMap[attName] = {
                        "value":"",
                        "inheritedValue":""
                    }

        else :
            for attName in moduleAttributes: 
                val, inheritedVal = sv.getAttributeValueForModule(app, view, moduleId, attName)

                moduleAttributeMap[attName] = {
                    "value":val,
                    "inheritedValue":inheritedVal
                }
            
            viewXML = sv.getViewXML(app,view)
            sv.addIdsToAllModules(viewXML)
            ourModule = viewXML.getElementById(moduleId)
            currentParamValues = sv.getParamDict(ourModule)
        
        isSupported = moduleClass not in sv.unsupportedModules

        return self.render_template("/sideview_utils:/templates/edit_module_params.html", {
            "app": app,
            "view" : view,
            "className": moduleClass,
            "isSupported" : isSupported,
            "module":definitions[moduleClass], 
            "moduleId":moduleId, 
            "moduleAttributeMap" : moduleAttributeMap,
            "parentModuleId": parentModuleId,
            "insertBeforeModuleId": insertBeforeModuleId,
            "currentParamValues": currentParamValues,
            "bigParams" : sv.bigParams,
            "listParams" : sv.listParams, 
            "base_url" : self.make_url("/static/app/sideview_utils/")
        })


    @expose_page(must_login=True, methods=['GET']) 
    def describe(self,moduleClass,param=None,**kwargs) :
        
        if (param=="layoutPanel") :
            text = """layoutPanel values are inherited from modules higher up 
            in the tree.  As such, you do NOT need to set layoutPanel values 
            on every module - set them only when you wish a particular module 
            to be in a different panel than its parent.  <br><br>When you see 
            a layoutPanel value in this interface that is greyed out, that is 
            just showing you the value that the module has inherited from 
            upstream. """

            return self.render_template("/sideview_utils:/templates/general_description.html", {
                "title":  moduleClass.replace("Splunk.Module.","") + ' - "layoutPanel" attribute',
                "text": text,
                "escapedText":"",
                "base_url" : self.make_url("/static/app/sideview_utils/")
            })

        elif (param=="group") :
            text = """group attributes are weird.  They are used to match 
            against selected subtrees when you're using a Switcher module 
            to display different modules to the user,  or when you're using 
            one of the old Splunk modules like PulldownSwitcher, 
            LinkSwitcher, TabSwitcher, etc...  I'd write more but I gotta 
            run to dinner. And you haven't read this far anyway.  
            Group attributes are weird and not very useful. Dont use them. """
            
            return self.render_template("/sideview_utils:/templates/general_description.html", {
                "title":  moduleClass.replace("Splunk.Module.","") + ' - "group" attribute',
                "text": text,
                "escapedText":"",
                "base_url" : self.make_url("/static/app/sideview_utils/")
            })

        elif (param=="autoRun") :
            text = """(optional) You can leave this attribute empty, or you 
            can set it to 'True'.  Do not set it to any other value, 
            including 'False'.  If set to True for a given module, then when 
            the page is loaded the module system will start a 'push' from 
            that point in the module tree.  Since 'pushes' can result in 
            searches and reports being dispatched automatically to satisfy 
            the demands of the downstream modules,  effectively autoRun 
            becomes a 'make my searches happen' trigger. """

            return self.render_template("/sideview_utils:/templates/general_description.html", {
                "title":  moduleClass.replace("Splunk.Module.","") + ' - "autoRun" attribute',
                "text": text,
                "escapedText":"",
                "base_url" : self.make_url("/static/app/sideview_utils/")
            })

        else :
            definitions = moduleMapper.getInstalledModules()

            module = definitions[moduleClass]
            
            if (param) :
                if (param.find(".")!=-1) :
                    param = param[0:param.find(".")+1] + "*"
                    paramObj = module["params"][param]
                else :
                    paramObj = module["params"][param]
                return self.render_template("/sideview_utils:/templates/param_description.html", {
                    "param":  paramObj, 
                    "module": module, 
                    "pname":param,
                    "base_url" : self.make_url("/static/app/sideview_utils/")
                    }
                )
            else :
                return self.render_template("/sideview_utils:/templates/module_description.html", {
                    "module": module,
                    "base_url" : self.make_url("/static/app/sideview_utils/")
                })