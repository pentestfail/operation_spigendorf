#Copyright (C) 2010-2015 Sideview LLC.  All Rights Reserved. 

import logging, time, json, re, copy, cherrypy, traceback, os
import lxml.etree as et
import splunk.entity as en
import splunk.appserver.mrsparkle.controllers as controllers
from splunk.appserver.mrsparkle.lib import i18n, times, cached
from splunk.appserver.mrsparkle.lib.decorators import expose_page
from splunk.appserver.mrsparkle.lib.routes import route
from splunk.appserver.mrsparkle.lib.memoizedviews import memoizedViews
from splunk.appserver.mrsparkle.lib.module import moduleMapper
from splunk.clilib import bundle_paths
from mako import exceptions

import sideview as sv

logger = logging.getLogger('splunk.appserver.controllers.view')

def pathsToURLs(paths) :
    for i in range(len(paths)) : 
        p = paths[i]
        segments = p.split(os.sep)
        try: moduleDirectoryIndex = segments.index("modules")
        except: return False
        paths[i] = "/" + "/".join(segments[moduleDirectoryIndex:])
    return paths

def toAppPath(p) :
    #p = "C:\\Program Files\\Splunk\\etc\\apps\\sideview_utils\\appserver\\modules\\HTML\\HTML.html"
    
    basedir = os.path.abspath(bundle_paths.get_base_path())
    if (p.find(basedir)==0) :
        p = p.replace(basedir + os.path.sep,"")
        segments = p.split(os.path.sep)
        
        #return "/sideview_utils:/modules/HTML/HTML.html"

        return "/" + segments[0] + ":/" + "/".join(segments[2:])
    else :
        p = "=" + p
    return p
    
def get_root_path():
    if hasattr(cherrypy.request, 'embed') and cherrypy.request.embed and cherrypy.request.config.get('embed_uri'):
        return cherrypy.request.config.get('embed_uri')
    else:
        return cherrypy.request.script_name
    
def getServerTimezoneOffset():
    if (time.localtime()[-1] == 1): 
        return time.altzone
    else:
        return time.timezone

@cached.memoized(cache_age=30)
def getServerZoneInfo():
    return times.getServerZoneinfo()
    
def getConfig() :
    c = {
    "MRSPARKLE_PORT_NUMBER" : cherrypy.config.get('tools.csrfcookie.port') or cherrypy.config.get("server.socket_port"),
    "DISPATCH_TIME_FORMAT"  : cherrypy.config.get("DISPATCH_TIME_FORMAT"),
    "MRSPARKLE_ROOT_PATH"   : get_root_path(),
    "BUILD_NUMBER"          : cherrypy.config.get("build_number", 0),
    "BUILD_PUSH_NUMBER"     : cherrypy.config.get("_push_version", 0),
    "LOCALE"                : i18n.current_lang_url_component(),
    "SERVER_TIMEZONE_OFFSET": getServerTimezoneOffset(),
    "SERVER_ZONEINFO"       : getServerZoneInfo()
    }
    return c

def fillInLayoutPanelAttribute(modElt, panelName) :
    for directChild in modElt.findall("module"):
        if (not directChild.attrib.get("layoutPanel",False)):
            directChild.attrib["layoutPanel"] = panelName
            fillInLayoutPanelAttribute(directChild,panelName)


def flattenModules(tree, moduleParamConf) :
    modules = []

    for modElt in tree.findall(".//module[@layoutPanel]"):
        fillInLayoutPanelAttribute(modElt,modElt.attrib.get("layoutPanel"))

    for modElt in tree.findall(".//module"):
        m = {}
        for attName in modElt.attrib:
            value = modElt.attrib.get(attName)
            if attName=="name":
                m["moduleName"] = value
            else :
                m[attName] = value
        

        for paramElt in modElt.findall("param"):
            paramName = paramElt.attrib.get("name")
            logger.error("scanning param " + paramName)
            listElts = paramElt.findall("list")
            if len(listElts)>0:
                listParam = []
                for listElt in listElts: 
                    listEntry = {}
                    for atom in listElt.findall("param"):
                        listEntry[atom.attrib.get("name")] = atom.text
                    listParam.append(listEntry)
                m[paramName] = listParam
            else :
                m[paramName] = paramElt.text
        
        parentElt = modElt.find("..")
        if (parentElt) :
            m["parentId"] = parentElt.attrib.get("id")
        
        logger.error(json.dumps(m))
        modules.append(m)
    for m in modules : 
        if m["moduleName"] in moduleParamConf:
            paramConf = moduleParamConf[m["moduleName"]]
            for paramName in paramConf:
                logger.error(paramName)
                if (paramName and paramName not in m and "default" in paramConf[paramName]) :
                    defaultValue= paramConf[paramName]["default"]
                    if (defaultValue!=None) :
                        m[paramName] = paramConf[paramName]["default"]
            
    return modules




class view(controllers.BaseController):
    
    

    def getViewArgs(self,view) :
        return {
            "label":view,
            "id":view,
            "refresh":-1,
            "objectMode":"no thanks",
            "displayView": view,
            "onunloadCancelJobs": 1,
            "autoCancelInterval": 100
        }
    
    

    ## eg: go to the lovely URL /custom/sideview_utils/view/sideview_utils/home
    @route('/:app/:view')
    @expose_page(must_login=True, methods=['GET'])
    def render(self, app, view, **kwargs):

        try: 
            viewEntity = en.getEntity('data/ui/views', view, namespace=app)
            viewXML = viewEntity[en.EAI_DATA_KEY]
            
            parser = et.XMLParser(remove_blank_text=True,strip_cdata=False)
            tree = et.XML(viewXML,parser)

            moduleCountMap = {}
            moduleTemplates = {}
            moduleParamConf = {}
            parentClasses = []
            allModules = moduleMapper.getInstalledModules();
            cssFiles = []
            jsFiles = []
            
            for module in tree.iter("module"):
                moduleName = module.get("name")

                # GTH AppBar. Tell them Sideview sent you.
                #if (moduleName=="AppBar") :
                #    moduleName = "NavBar"
                #    module.set("name",moduleName)
                fullModuleName = "Splunk.Module." + moduleName
                m =  allModules.get(fullModuleName, {})
                
                if "params" in m:
                    moduleParamConf[moduleName] = m["params"]
                if "html" in m :
                    moduleTemplates[moduleName] = toAppPath(m["html"])
                if "css" in m and not m["css"] in cssFiles:
                    cssFiles.append(m["css"])
                if "js" in m and not m["js"] in jsFiles:
                    jsFiles.append(m["js"])

                if fullModuleName not in moduleCountMap :
                    moduleCountMap[fullModuleName] = 0;
                module.set("id", moduleName + "_" + str(moduleCountMap[fullModuleName]))
                moduleCountMap[fullModuleName] += 1

                inheritance = m.get("inheritance")
                for c in inheritance:
                    if (c in parentClasses) : continue
                    if (c in moduleCountMap) : continue
                    if (c=="Splunk.Module"): continue
                    if (c=="Splunk.Module.DispatchingModule"): continue
                    parentClasses.append(c)


            if (len(parentClasses)>0):
                return "error - we dont support any legacy splunk modules that have intermediate parent classes"
            


            cherrypy.response.headers['content-type'] = "text/html; charset=utf-8"

            template = tree.get("template","/sideview_utils:/templates/sv_dashboard.html")
            
            jsFiles  = pathsToURLs(jsFiles)
            cssFiles = pathsToURLs(cssFiles)


            modules = flattenModules(tree, moduleParamConf)
            try :
                return self.render_template("/APP/sideview_utils/appserver/templates/view/dashboard.html", {
                    "jsFiles": jsFiles,
                    "cssFiles": cssFiles,
                    "moduleTemplates" : moduleTemplates,
                    "modules": modules,
                    "modulesJSON" : json.dumps(modules),
                    "splunkWebConfigJSON": json.dumps(getConfig()),
                    'APP': dict(id=app)
                })
            except Exception, e: 
    
                rt = exceptions.RichTraceback()
                stack = []
                for (filename, lineno, function, line) in rt.traceback:
                    stack.append("File %s, line %s, in %s" % (filename, lineno, function))
                    stack.append(line + "\n")
                stack.append("%s: %s" % (str(rt.error.__class__.__name__), rt.error))
                return "\n".join(stack)
                    
        except Exception, e:
            return "<pre>" + str(e) + "\n\n" + str(traceback.format_exc(e)) + "</pre>"




        
        
    @expose_page(must_login=True, methods=['GET']) 
    def show(self, app, view, **kwargs):
        cherrypy.response.headers['Content-Type'] = "text/xml"

        uglyXML = sv.getViewXML(app,view)
        uglyXML = uglyXML.toxml()
        parser = et.XMLParser(remove_blank_text=True,strip_cdata=False)
        etXML = et.XML(uglyXML,parser)
        prettyXML = et.tostring(etXML,pretty_print=True)

        viewXML = sv.patchXMLForReadability(prettyXML)
        return viewXML

    # returns a simplified version of the module tree in JSON.
    @expose_page(must_login=True, methods=['GET']) 
    def spacetree(self,app,view,**kwargs) :
        viewXML = sv.getViewXML(app,view)
        selectedNode = kwargs.get("selectedNode",None)
            
        if (len(viewXML.getElementsByTagName("view"))>0) :
            sv.addIdsToAllModules(viewXML)
            viewJSON = {}
            viewJSON["id"] = view
            viewJSON["name"] = view
            viewJSON["data"] = {"isView": True}
            
            if (viewXML.childNodes.length>0) : 
                viewTag = viewXML.getElementsByTagName("view")[0]
                sv.buildModulesAsJSON(viewJSON, viewTag)

            return self.render_template("/sideview_utils:/templates/spacetree.html", {
                "app" : app, 
                "view": view, 
                "selectedNode" : selectedNode,
                "base_url" : self.make_url("/static/app/sideview_utils/"), 
                "viewJSON" : json.dumps(viewJSON)
            })

        else :
            if (len(viewXML.getElementsByTagName("form"))>0):
                simplifiedXMLType="form"
            elif (len(viewXML.getElementsByTagName("dashboard"))>0):
                simplifiedXMLType="dashboard"
            else :
                simplifiedXMLType=None
            
            message = []
            if (simplifiedXMLType):
                message.append("it looks like this is a <b>&lt;")
                message.append(simplifiedXMLType)
                message.append('&gt;</b> view.  You can try converting this view to the advanced XML using the process described <a target="_blank" href="http://splunk-base.splunk.com/answers/1/how-can-i-convert-simple-view-xml-to-advanced-xml">here.</a> ');
            else :
                message.append("We're not sure what happened here,but the Sideview Editor was unable to read the XML for this view.")

            return self.render_template("/sideview_utils:/templates/general_description.html", {
                "title":  "Sorry the Sideview Editor does not support editing views written using Splunk's Simplified XML.",
                "text":"",
                "escapedText": "".join(message),
                "base_url" : self.make_url("/static/app/sideview_utils/")
            })



    @expose_page(must_login=True, methods=['GET']) 
    def edit(self,view,app) :
        
        if (view=="_new") :
            viewXML = sv.getBlankViewXML()
        else :
            viewXML = sv.getViewXML(app,view)
        
        viewAttributes = sv.getViewAttributeMap()
        
        # weird looking, but we just want the keys so we wipe the values.
        for name,val in viewAttributes.items() :
            viewAttributes[name] = ""

        viewNode = viewXML.getElementsByTagName("view")[0]

        for name,value in viewNode.attributes.items():
            viewAttributes[name] = viewNode.getAttribute(name)
            
        label = sv.getText(viewXML.getElementsByTagName("label")[0])

        return self.render_template("/sideview_utils:/templates/edit_view_params.html", {
            "viewAttributes":viewAttributes, 
            "label" : label, 
            "app":app,
            "view":view, 
            "base_url" : self.make_url("/static/app/sideview_utils/", translate=False)
        })

    @expose_page(must_login=True, methods=['GET']) 
    def describe(self,param=None,**kwargs) :

        m = sv.getViewAttributeMap()
        if (param == "label") :
            text = """(required) When set, this value will represent the view in navigation menus"""
        elif (param=="name") :
            text = """(required) This determines the name of the view in URL's 
            and determines the name of the XML file(s) on disk.  You can only set 
            this value when the view is first created."""
        else :
            text = m.get(param,False)

        return self.render_template("/sideview_utils:/templates/general_description.html", {
            "title":  'view param "' + param  + '"',
            "text": text,
            "escapedText": "",
            "base_url" : self.make_url("/static/app/sideview_utils/", translate=False)
        })

    @expose_page(must_login=True, methods=["POST"]) 
    def update_view_props(self,app,view,label, **kwargs):
        
        if (not self.viewIsEditable(app,view)) :
            return self.getUneditableAppResponse(app,view)

        if (view=="_new") :
            viewNameIfNew = kwargs.get("name")
            viewXML = sv.getBlankViewXML()
        else :
            viewNameIfNew = None
            viewXML = sv.getViewXML(app,view)

        viewAttributes = sv.getViewAttributeMap()

        viewNode = viewXML.getElementsByTagName("view")[0]
        
        existingAttributeMap = {}
        for name,value in viewNode.attributes.items():
            existingAttributeMap[name] = value
        for name in viewAttributes:
            if (kwargs.get(name,None)) :
                viewNode.setAttribute(name,kwargs[name])
            elif (name in existingAttributeMap):
                viewNode.removeAttribute(name)
        
        labelNode = viewXML.getElementsByTagName("label")[0]
        sv.clearContents(labelNode)
        sv.setText(viewXML, labelNode, label)
        updateMetaData = "action=viewPropertyEdit"

        errorMessage = sv.commitChanges(app,view,viewXML,updateMetaData,viewNameIfNew)
        if (errorMessage) :
            return self.getErrorResponse(errorMessage)
        return '{"success":true}'


    
    @expose_page(must_login=True, methods=["POST"]) 
    def delete_module(self, app, view, moduleId, **kwargs) :
        
        if (not self.viewIsEditable(app,view)) :
            return self.getUneditableAppResponse(app,view)
        
        viewXML = sv.getViewXML(app,view)

        sv.addIdsToAllModules(viewXML)
        moduleToDelete = viewXML.getElementById(moduleId)
        if (not moduleToDelete) :
            return '{"success":false,"message": "No module with id ' + moduleId + ' could be found to delete. Check your selection and try again."}'

        parentNode = moduleToDelete.parentNode
        parentNode.removeChild(moduleToDelete)

        updateMetaData = "action=deleteModule moduleId=" + str(moduleId)
        errorMessage = sv.commitChanges(app,view,viewXML,updateMetaData)
        if (errorMessage) :
            return self.getErrorResponse(errorMessage)
        return '{"success":true}'
    
    @expose_page(must_login=True, methods=['POST']) 
    def reattach_module(self, view, app, moduleId, parentModuleId, **kwargs) : 
        # weirdness in exception handling, where an exception deeper in, 
        # triggers a useless error message and a 404 response, where the 
        # response complains about optional args not being passed.
        # I'm writing it this way, just so that problem doesn't slow us down 
        # when we hit inevitable exceptions during development.
        insertBeforeModuleId=kwargs.get("insertBeforeModuleId",None) 
        successMessage=kwargs.get("successMessage",None) 

        if (not self.viewIsEditable(app,view)) :
            return self.getUneditableAppResponse(app,view)

        if (moduleId == parentModuleId) :
            return '{"success":false,"message": "Sorry but you just tried to make ' + moduleId + ' a parent of itself.  Check your field values and try again."}'

        viewXML = sv.getViewXML(app,view)

        sv.addIdsToAllModules(viewXML)
        ourModule = viewXML.getElementById(moduleId)
        newParent = viewXML.getElementById(parentModuleId)

        if (not ourModule) :
            return '{"success":false,"message": "No module with id ' + moduleId + ' could be found. Check your selections and try again."}'

        
        if (not newParent and parentModuleId!="(the view itself)") :
            return '{"success":false,"message": "No module with id ' + parentModuleId + ' could be found. Check your selections and try again."}'
        

        if (sv.isDownstream(newParent,ourModule)) :
            return '{"success":false,"message": "You just tried to Reattach ' + moduleId + ' downstream from one of its *own* downstream modules.  This would effectively delete modules from the view so it has not been done."}'


        # drum roll please
        oldParent = ourModule.parentNode
        oldParent.removeChild(ourModule)

        # if the module will become a top-level module AND it doesn't have layoutPanel set,  
        # then explicitly give it the layoutPanel that its old parent had.
        if (parentModuleId=="(the view itself)") :
            newParent=viewXML.getElementsByTagName("view")[0]
            if (not ourModule.hasAttribute("layoutPanel")) :
                value, inheritedValue = sv.getAttributeValueForModule(app,view,oldParent.getAttribute("id"), "layoutPanel")
                explicitLayoutPanel = value
                if (not explicitLayoutPanel) :
                    explicitLayoutPanel = inheritedValue 
                ourModule.setAttribute("layoutPanel", explicitLayoutPanel)

        if (insertBeforeModuleId) :
            if (insertBeforeModuleId == moduleId) :
                return '{"success":false,"message": "Sorry but you tried to insert ' + moduleId + ' just before itself and that\'s not possible.  Check your field values and try again."}'

            insertBeforeModule = viewXML.getElementById(insertBeforeModuleId)
            if (insertBeforeModule and insertBeforeModule.parentNode != newParent) :
                return '{"success":false,"message": "Sorry but ' + insertBeforeModuleId + ' is not itself a child of ' + parentModuleId+ ' so this is impossible. Please check your field values and try again."}'

            newParent.insertBefore(ourModule,insertBeforeModule)
        else : 
            newParent.appendChild(ourModule)
        
        updateMetaData = "action=moduleReattached moduleId=%s parentModuleId=%s insertBeforeModuleId=%s" % (moduleId, parentModuleId, insertBeforeModuleId)
        errorMessage = sv.commitChanges(app,view,viewXML, updateMetaData)
        if (errorMessage) :
            return self.getErrorResponse(errorMessage)
        return '{"success":true}'
        
    
    
    @expose_page(must_login=True, methods=["POST"]) 
    def update(self, app, view, moduleId, **kwargs) :

        if (not self.viewIsEditable(app,view)) :
            return self.getUneditableAppResponse(app,view)
            
        viewXML = sv.getViewXML(app,view)
        sv.addIdsToAllModules(viewXML)
        
        moduleParams = {}
        
        # we avoid using optional args in the controller to avoid the buggy exception handling in Splunk's python code for controllers.
        parentModuleId=kwargs.get("parentModuleId",None) 
        insertBeforeModuleId=kwargs.get("insertBeforeModuleId",None) 
        moduleClass=kwargs.get("moduleClass",None) 

        legalAttributeValues = sv.getLegalValuesForModule(viewXML,moduleClass)
        
        moduleAttributeMap = {
            "layoutPanel" : kwargs.get("layoutPanel",None),
            "autoRun": kwargs.get("autoRun",None),
            "group": kwargs.get("group",None)
        }
        
        
        for attName in legalAttributeValues :
            submittedValue = kwargs.get(attName,None)
            attDict = legalAttributeValues[attName]
            if (submittedValue):
                if ("values" in attDict and attDict["values"] and submittedValue not in attDict["values"]) :
                    return self.getAttributeErrorResponse(attName,attDict["values"],submittedValue,attDict["required"])
            elif ("required" in attDict and attDict["required"]) :
                return '{"success":false,"message": "' + attName + ' is a required field."}'


        for arg in kwargs: 
            if (arg not in {"view","app","moduleID","parentModuleId","insertBeforeModuleId","layoutPanel","autoRun","group","moduleClass","splunk_form_key"}) :
                value = kwargs[arg]
                try : 
                    # json.loads will turn false to False and true to True so 
                    # we guard against that here.
                    if (value!="false" and value!="true" and value[0]!='"' and value[-1]!='"') :
                        value = json.loads(value)
                except Exception,e:
                    m = "exception trying convert following string to json - " + str(value)
                    logger.error(m)
                    
                moduleParams[arg] = value
                
        if (moduleId=="_new" and moduleClass) :
            if (parentModuleId!="_top") : 
                parentModule = viewXML.getElementById(parentModuleId)
                ourModule = viewXML.createElement("module")
                ourModule.setAttribute("name",moduleClass)
                if (insertBeforeModuleId and insertBeforeModuleId != parentModuleId) :
                    insertBeforeModule = viewXML.getElementById(insertBeforeModuleId)
                    parentModule.insertBefore(ourModule,insertBeforeModule)
                else :
                    parentModule.appendChild(ourModule)
                
            else : 
                
                viewNode = viewXML.getElementsByTagName("view")[0]
                ourModule = viewXML.createElement("module")
                ourModule.setAttribute("name",moduleClass)
                ourModule.setAttribute("layoutPanel","appHeader")
                viewNode.appendChild(ourModule)

        else :
            ourModule = viewXML.getElementById(moduleId)
            #logger.error("we are editing this module: " + moduleId)
        
        if (ourModule.parentNode.tagName=="view") :
            layoutPanel = kwargs.get("layoutPanel",None) 
            if (not layoutPanel) :
                return self.getErrorResponse("all top level modules must have a value set for 'layoutPanel'.")

        for attName,attValue in moduleAttributeMap.items() :
            if (attValue) :
                ourModule.setAttribute(attName,attValue)
            elif (ourModule.hasAttribute(attName)) :
                ourModule.removeAttribute(attName)
            
        for param in ourModule.childNodes :
            if (param.nodeType == param.TEXT_NODE) :
                ourModule.removeChild(param)

        for param in ourModule.childNodes :
            if (param.nodeType != 1 or param.tagName!="param") :
                continue;
            paramName = param.getAttribute("name")
            sv.clearContents(param)

            if paramName in moduleParams :
                value = moduleParams[paramName]
                if (isinstance(value,list)) :
                    sv.setListParam(viewXML, param, value)
                elif (sv.isBigParam(moduleClass,paramName)) :
                    sv.setCDATA(viewXML, param, value)
                else :
                    sv.setText(viewXML, param, value)
                del moduleParams[paramName]
            else :
                ourModule.removeChild(param)
                
        
        for remainingParamName in moduleParams : 
            newParam = viewXML.createElement("param")
            
            newParam.setAttribute("name", remainingParamName)
            
            value = moduleParams[remainingParamName]
            if (isinstance(value,list)) :
                sv.setListParam(viewXML, newParam, value)
            else :
                sv.setText(viewXML, newParam, str(value))

            
            if (ourModule.childNodes.length>0) :
                ourModule.insertBefore(newParam, ourModule.childNodes[0])
            else : 
                ourModule.appendChild(newParam)

        if (moduleId=="_new") :
            updateMetaData = "action=moduleAdded moduleClass=%s parentModuleId=%s insertBeforeModuleId=%s" % (moduleClass, parentModuleId, insertBeforeModuleId)
        else:
            updateMetaData = "action=moduleEdited moduleId=%s parentModuleId=%s insertBeforeModuleId=%s" % (moduleId, parentModuleId, insertBeforeModuleId)

        errorMessage = sv.commitChanges(app,view,viewXML, updateMetaData)
        if (errorMessage) :
            return self.getErrorResponse(errorMessage)
        return '{"success":true}'


    def viewIsEditable(self,app,view) :
        if (app=="sideview_utils"):
            return (view.find("example_")==0)
        else :
            return (app not in sv.uneditableViews or view not in sv.uneditableViews[app])

    def getErrorResponse(self,message) :
        resp = {"success":False}
        resp["message"] = str(message)
        return json.dumps(resp)

    def getUneditableAppResponse(self,app,view) :
        sideviewMessage = """We cannot let you use the Sideview Editor to edit 
        pieces of the Sideview app itself because that would be too silly.  
        You are however free to edit any view whose name begins with the word 'example'."""
        generalMessage = """This view has been mysteriously marked as uneditable. 
        Or maybe it wasn't mysterious.  Honestly we can't tell. But you can't edit it."""
        
        if (app=="sideview_utils") :
            return self.getErrorResponse(sideviewMessage)
        else :
            return self.getErrorResponse(generalMessage)

    def getAttributeErrorResponse(self,attName, legalValues, submittedValue, isRequired) :
        resp = {"success":False}
        messageTemplate = "ERROR - %s is not allowed as a value for %s. Set one of the allowed values - (%s)"
        if (isRequired) : 
            messageTemplate += "."
        else :
            messageTemplate += " or leave it blank."

        resp["message"] = messageTemplate % (submittedValue, attName, ", ".join(legalValues))
        return json.dumps(resp)
