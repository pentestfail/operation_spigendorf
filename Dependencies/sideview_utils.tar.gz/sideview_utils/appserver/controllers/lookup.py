#Copyright (C) 2010-2015 Sideview LLC.  All Rights Reserved. 

import logging, cherrypy, cgi, random, os, platform, csv, urllib
import splunk.appserver.mrsparkle.controllers as controllers
from splunk.appserver.mrsparkle.lib.decorators import expose_page
from splunk.appserver.mrsparkle.lib import util
import splunk.entity as en


logger = logging.getLogger('splunk.appserver.controllers.lookup')


class lookup(controllers.BaseController):

    def redirectWithError(self, redirectUrl, error) :
        self.redirect_to_url(redirectUrl + "&success=false&error=" + urllib.quote(error))


    @expose_page(must_login=True, methods=['GET','POST']) 
    def update(self, lookupFile, lookupName, app, currentApp="sideview_utils", currentView="update_lookup", **kwargs):
        
        redirectUrl = "/app/" + currentApp + "/" + currentView + "?app=" + app + "&lookupName=" + lookupName
        if (kwargs.get("redirectOverride",None)) :
            redirectUrl = kwargs.get("redirectOverride")
            if (redirectUrl.find("?")==-1) :
                redirectUrl += "?"

        if not (isinstance(lookupFile, cgi.FieldStorage) and lookupFile.file):
            return _('No file was uploaded')

        endpointPath = 'data/lookup-table-files'
        existingEntity = en.getEntity(endpointPath,lookupName, namespace=app, uri=None, sessionKey=cherrypy.session['sessionKey'])
        
        existingFilePath = existingEntity["eai:data"]

        if (platform.system()=="Windows" and existingEntity["eai:acl"] and existingEntity["eai:acl"]["sharing"] == "user") :
            return self.redirectWithError(redirectUrl,"Due to some permissions problems with how Splunk writes to non-shared lookup files, we cannot reupload this lookup.  First use the 'Permissions' link in Manager to share this lookup with all users of the given app and then try again.")
            

        tempFilePath, error = self.createTempLookup(lookupFile, lookupName, app, existingFilePath);
        
        if (not tempFilePath) :
            return self.redirectWithError(redirectUrl,"Unable to write temp file to the relevant lookup directory : " + str(error))
            
        try :
            existingHeaderRow = self.getHeaderRow(existingFilePath)
        except Exception, e:
            return self.redirectWithError(redirectUrl,"Something went wrong when we tried to get the header row of the existing lookup file : " + str(e))
            
        try :
            newHeaderRow = self.getHeaderRow(tempFilePath)
        except Exception, e:
            if os.path.exists(tempFilePath):
                os.remove(tempFilePath)
            return self.redirectWithError(redirectUrl,"Something went wrong when we tried to get the header row of the temporary file : " + str(e))
        existingHeaderRow.sort()
        newHeaderRow.sort()

        if (",".join(existingHeaderRow) != ",".join(newHeaderRow)) :
            if os.path.exists(tempFilePath):
                os.remove(tempFilePath)
            return self.redirectWithError(redirectUrl,"The header rows on your new lookup do not match the rows on the old lookup. You will have to delete and recreate the lookup in Manager.")
            
        # if somehow there's an old file lingering from a failed previous attempt.
        if os.path.exists(existingFilePath+".bak"):
            os.remove(existingFilePath+".bak")

        # move the old file out of the way and only delete it after.
        os.rename(existingFilePath, existingFilePath+".bak")
        os.rename(tempFilePath, existingFilePath)

        os.remove(existingFilePath+".bak")
        
        if os.path.exists(tempFilePath):
            os.remove(tempFilePath)

        return self.redirect_to_url(redirectUrl + "&success=true&message=" + urllib.quote("The " + lookupName + " lookup has been successfully updated"))

    def getHeaderRow(self, filePath) :
        headerList = []
        with open(filePath, "r") as f:
            reader = csv.reader(f)
            headerList = reader.next()
        return headerList


    def createTempLookup(self, lookupFile, lookupName, app, existingFilePath) :
        tempFileName = lookupName + str(random.random())[1:]
        try :
            existingLookupDir, existingLookupFile = os.path.split(existingFilePath)
        except Exception, e:
            return False, "error determining existing lookup path " + str(e)
    
        try:
            line = lookupFile.file.readline()
            if not line:
                return False, _("The file you have uploaded seems to be empty.")
            
            #lookupDir = util.make_splunkhome_path(['etc', 'apps', app, 'lookups'])
            #if not os.path.exists(lookupDir):
            #    os.makedirs(lookupDir, 0755)

            tempFilePath = os.path.join(existingLookupDir, tempFileName)
            
            dstDirNorm = os.path.dirname(os.path.normpath(tempFilePath))
            lookupDirNorm = os.path.normpath(existingLookupDir)
            if dstDirNorm != lookupDirNorm:
                return False, _('Something went wrong with the lookup names. Does your lookup name perhaps contain slashes, backslashes, or a "../"?')
            
            if os.path.exists(tempFilePath):
                return False, _('This should never occur but it did. Our randomly generated filename collided with an existing file. Try again.')
            
            with open(tempFilePath, "w") as f:
                f.write(line)
                for line in lookupFile.file:
                    f.write(line)
            
            return tempFilePath, ""

        except Exception, e:
            try:
                if os.path.exists(tempFilePath):
                    os.remove(tempFilePath)
            except: 
                pass
            return False, "Unknown exception creating temp lookup file " + str(e)

