// Copyright (C) 2010-2015 Sideview LLC.  All Rights Reserved.


Splunk.Module.SideviewUtils = $.klass(Splunk.Module, {

    initialize: function($super, container) {
        var retVal = $super(container);
        this.toneDownJobber();
        if (this.getParam("checkAutoRunAttributes")=="True") {
            this.checkAutoRunAttributes();
        }
        return retVal;
    },

    checkAutoRunAttributes: function() {
        $(document).bind("allModulesInHierarchy", function() {
            setTimeout(function() {
                var moduleLoader = Splunk.Globals["ModuleLoader"];
                var modules = moduleLoader._modules;
                var modulesAlreadyChecked = {};
                var breakOut = false;
                var innerModule, outerModule;
                for (var i=0,len=modules.length;i<len;i++) {
                    innerModule = modules[i];
                    if (!Sideview.utils.normalizeBoolean(innerModule.getParam("autoRun"))) continue;
                    modulesAlreadyChecked[innerModule.moduleId] = true;
                    outerModule = innerModule;
                    while (outerModule.hasOwnProperty("parent") && outerModule.parent){
                        outerModule = outerModule.parent;
                        if (Sideview.utils.normalizeBoolean(outerModule.getParam("autoRun"))) {
                            breakOut = true;
                            break;
                        }
                        modulesAlreadyChecked[outerModule.moduleId] = true;
                    } 
                    if (breakOut) break;
                }
                if (breakOut) {
                    var messenger = Splunk.Messenger.System.getInstance();
                    messenger.send('error', 'splunk', "AUTORUN ERROR: The creator of this view has left an autoRun=\"True\" nested inside another autoRun=\"True\". This causes numerous significant problems in the Splunk UI and is of no benefit. Remove the inner one (currently on the " + innerModule.moduleId + " module) and check the view thoroughly because there may be more.");
                }
            })
        });
    },

    /**
     * tone down the Jobber's super aggressive defaults
     */
    toneDownJobber: function() {
        Splunk.Globals['Jobber'].MIN_POLLER_INTERVAL = 500;
        Splunk.Globals['Jobber'].MAX_POLLER_INTERVAL = 1500;
        Splunk.Globals['Jobber'].POLLER_CLAMP_TIME   = 3000;
    }
});



