// Copyright (C) 2010-2015 Sideview LLC.  All Rights Reserved.

Splunk.Module.ShowHide= $.klass(Splunk.Module, {

    initialize: function($super, container) {
        $super(container);
        this.logger = Sideview.utils.getLogger();
        this.checkConfig();
        Sideview.utils.applyCustomProperties(this);
        var show = this.getParam("show");
        var hide = this.getParam("hide");
        this.selectorsToShow = show ? show.split(",") : [];
        this.selectorsToHide = hide ? hide.split(",") : [];
    },

    resetUI: function() {},

    checkConfig: function() {
        if (this.show.length + this.hide.length < 1) {
            this.displayInlineErrorMessage("ShowHide module is configured with neither any selectors to show nor any to hide");
        }
    },
    
    
    onContextChange: function() {
        for (var i=0,len=this.selectorsToHide.length; i<len; i++) {
            $(this.selectorsToHide[i]).hide();
        }
        for (var i=0,len=this.selectorsToShow.length; i<len; i++) {
            $(this.selectorsToShow[i]).show();
        }
        
    }
});




