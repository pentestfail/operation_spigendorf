// Copyright (C) 2010-2015 Sideview LLC.  All Rights Reserved.
Splunk.Module.Report = $.klass(Splunk.Module, {

    initialize: function($super, container) {
        $super(container);
        this.logger = Sideview.utils.getLogger();
        this.childEnforcement = Splunk.Module.ALWAYS_REQUIRE;
        
        Sideview.utils.applyCustomProperties(this);
    },

    getReportStr: function() {
        var r = [];
        
        var internalContext = this.getContext();
        var stat   = Sideview.utils.replaceTokensFromContext(this.getParam("stat"), internalContext);
        var xField = Sideview.utils.replaceTokensFromContext(this.getParam("xField"), internalContext);
        var yField = Sideview.utils.replaceTokensFromContext(this.getParam("yField"), internalContext);
        var zField = Sideview.utils.replaceTokensFromContext(this.getParam("zField"), internalContext);
        
        internalContext.set("stat", stat);
        internalContext.set("xField", xField);
        internalContext.set("yField", yField);
        internalContext.set("zField", zField);

        if (xField=="_time") r.push("timechart");
        else r.push("chart");
        if (stat && yField) r.push("$stat$($yField$)");
        else r.push("count");
        if (xField!="_time") r.push("over $xField$");
        if (zField) r.push("by $zField$")
        
        return Sideview.utils.replaceTokensFromContext(r.join(" "), internalContext);
    },

    getModifiedContext: function(context) {
        var reportStr = this.getReportStr();
        if (!context) context = this.getContext();
        var xField = Sideview.utils.replaceTokensFromContext(this.getParam("xField"), context);
        var splitByField = Sideview.utils.replaceTokensFromContext(this.getParam("zField"), context);
        context.set("sideview.xField", xField);
        context.set("sideview.splitByField", splitByField);
        context.set("sideview.reportKey", this.getParam("name"));
        context.set(this.getParam("name"), reportStr);

        return context;
    }
});