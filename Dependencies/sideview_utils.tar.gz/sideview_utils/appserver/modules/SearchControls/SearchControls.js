// Copyright (C) 2010-2015 Sideview LLC.  All Rights Reserved.

Splunk.Module.SearchControls= $.klass(Sideview.utils.getBaseClass(true), {
    
    initialize: function($super, container) {
        $super(container);
        this.logger = Sideview.utils.getLogger();
        Sideview.utils.applyCustomProperties(this);
        this.messenger = Splunk.Messenger.System.getInstance();
        this.setFloatingBehavior();
        this.setupEventHandlers();
        this.stateWrapper = $(".stateWrapper", this.container);
        this.state = "null";

        this.initMenus();
    },
    requiresResults: function() {return true;},

    getCurrentJob: function() {
        var search = this.getContext().get("search");
        if (search.isJobDispatched()) return search.job;
        else false;
    },

    /**
     * Instead of wiring up each individually,  we just map the classNames 
     * to the methodNames exactly.
     * corrolary: never add a class like 'resetUI' or 'pushContextToChildren'!
     */
    setupEventHandlers: function() {
        var moduleRef = this;
        $("a", this.container).not(".splButton-primary").click(function(evt) {
            moduleRef.hideMenus();
            evt.preventDefault();
            var className = $(this).attr('class');
            className = className
                .replace("splButton-primary ", "")
                .replace("splButton-tertiary ", "");
            if (moduleRef[className]) {
                moduleRef[className](evt);
            }
            evt.stopPropagation();
            
            return false;
        });
    },



    /**
     * sets floats and clears as determined by the config.
     */
    setFloatingBehavior: function() {
        // unfortunately a module's mako template cannot control its *own* 
        // container div.  So we are forced to float it here.
        if (this.getParam("float")) {
            $(this.container).css("float", this.getParam("float"));
        }
        if (this.getParam("clear")) {
            $(this.container).css("clear", this.getParam("clear"));
        }
    },

    background: function(evt) {
        var job = this.getCurrentJob();
        if (job) {
            job.save();
            if (job.isPreviewable()) job.setPreviewable(false);
            this.withEachDescendant(function(module) {
                module.reset();
            });
            var app = job['_eai:acl']['app'] || Sideview.utils.getCurrentApp();
            var view = job['_request']['ui_dispatch_view'] || Sideview.utils.getCurrentView();
            var url = sprintf("app/%s/%s?sid=%s", app, view, job.getSearchId());

            this.messenger.send('info', "splunk.search.job", _('Your search job has been backgrounded. To retrieve it, visit [['+url+'| this page]]. Backgrounded jobs expire after 1 week.'));
        }
    },

    /** just here to catch the click, because the button's class changes from 
     *  pause to unpause at runtime. 
     */
    unpause: function(evt) {
        this.pause(evt);
    },

    pause: function(evt) {
        var job = this.getCurrentJob();
        if (job) {
            var oldClass = "pause";
            var newClass = "unpause";
            if (job.isPaused()) {
                var tmp = oldClass;
                oldClass=newClass;
                newClass=tmp;
                job.unpause();
                this.update("progress");
            } else {
                job.pause();
                this.update("paused");
                //this.messenger.send('info', "splunk.search.job", _('Your search job has been paused.'));
            }
            $("a." + oldClass, this.container).removeClass(oldClass).addClass(newClass);
        }
    },

    finalize: function(evt) {
        var job = this.getCurrentJob();
        if (job) {
            job.finalize();
        }    
    },

    cancel: function(evt) {
        var job = this.getCurrentJob();
        if (job) {
            job.cancel(
                function() {
                    this.messenger.send("info", "splunk.search", _("Your search has been cancelled."));
                }.bind(this),
                function() {
                    this.messenger.send("error", "splunk.search", _("Failed to cancel search."));
                }.bind(this)
            );
        }
        this.update("null");
    },
    
    inspector: function(evt) {
        var job = this.getCurrentJob();
        if (job) {
            var sid = job.getSearchId()
            if (sid) Splunk.window.openJobInspector(sid);
        }
    },

    saveSearch: function(evt) {
        var search = this.getContext().get("search");
        var popup = Splunk.Popup.SaveSearchWizard(search);
        Sideview.utils.addExtraSavedSearchFields(popup, this);
    },

    saveResults: function(evt) {
        var job = this.getCurrentJob();
        if (job) {
            job.save(
                function() {
                    this.messenger.send("info", "splunk.search", _("These search results have been saved. You can retrieve them later via the jobs manager."));
                }.bind(this),
                function() {
                    this.messenger.send("error", "splunk.search", _("Failed to save search results.  The search job may have expired."));
                }.bind(this)
            );
        }
    },

    saveAndShareResults: function(evt) {
        var formContainer = $(".shareLinkForm",this.container)[0];
        var title = _("Save and Share Results");
        var search = this.getContext().get("search");
        var popup = Splunk.Popup.createShareLinkForm(formContainer, title, search);
        //Sideview.utils.addExtraSavedSearchFields(popup, this);
    },
    createDashboardPanel: function(evt) {
        var search = this.getContext().get("search");
        var mode = "event";
        if (search.job.areResultsTransformed()) {
            mode = "table";
            this.withEachDescendant(function(module) {
                var id = module.moduleId;
                var c = module.getContext();
                if ((id.indexOf("JSChart")==0 || id.indexOf("FlashChart")==0) &&
                    $(module.container).is(":visible")) {
                    var chartType = c.get("charting.chart");
                    if (chartType) mode = chartType; 
                    return;
                }
            });
        }
        var popup = Splunk.Popup.DashboardWizard(search, {panel_type: mode});
        Sideview.utils.addExtraSavedSearchFields(popup, this);
    },

    createAlert: function(evt) {
        var search = this.getContext().get("search");
        var popup = Splunk.Popup.AlertWizard(search);
        Sideview.utils.addExtraSavedSearchFields(popup, this);
    },

    //createReport: function(evt) {
    //    alert("not implemented yet");
    //},

    createEventType: function(evt) {
        var search  = this.getContext().get("search");
        var formContainer = $(".eventtypeForm", this.container)[0];
        var popup = Splunk.Popup.createEventtypeForm(formContainer, _('Save As Event Type'), search);
        Sideview.utils.addExtraSavedSearchFields(popup, this);
    },

    createScheduledSearch: function(evt) {
        var search = this.getContext().get("search");
        var popup = Splunk.Popup.ScheduleDigestWizard(search, {title: _("Create Scheduled Search")});
        Sideview.utils.addExtraSavedSearchFields(popup, this);
    },

    print: function(evt) {
        $(document).trigger("PrintPage");
    },
     

    "export": function(evt) {
        var context = this.getContext();
        var formContainer = $(".exportPopup",this.container)[0];
        var search = context.get("search");
        if (!search.isJobDispatched() || !search.job || !search.job.isDone()){
            return;
        }

        var exportForm = $("form.exForm",formContainer);
        var postProcess = search.getPostProcess() || "";

        var layer = this.launchExportPopup(formContainer);

        layer.find("input[name='sid']").val(search.job.getSID())
        layer.find("input[name='search']").val(postProcess);
        layer.find("form.exForm").attr("action",Sideview.utils.make_url("/custom/sideview_utils/export/results"));

        if(search.job.areResultsTransformed()){
            $("option[value='raw']", layer).remove();
        }
    },

    launchExportPopup: function(formContainer) {

        var exportPopupHandle = null;
        var exportPopup = new Splunk.Popup(formContainer, {
            title: _("Export Results"),
            buttons: [
                {
                    label: _("Cancel"),
                    type: "secondary",
                    callback: function(){return true;}
                },
                {
                    label: _("Export"),
                    type: "primary",
                    callback: function(){
                        var limit = $(exportPopupHandle).find('[name="spl_ctrl-limit"]:checked').val();
                        if (limit == "unlimited") {
                             $(exportPopupHandle).find('[name="count"]').val("0");
                        } else {
                            var countstr =  $(exportPopupHandle).find('[name="spl_ctrl-count"]').val();
                            var count =  parseInt(countstr, 10);
                            if (isNaN(count) || count<1 || countstr!=count) {
                                alert(_("Must export at least one result"));
                                return false;
                            }
                            $(exportPopupHandle).find('[name="count"]').val(count);
                        }
                        return $(exportPopupHandle).find(".exForm").submit();
                    }
                }
            ]
        });
        exportPopupHandle = exportPopup.getPopup();
        return exportPopupHandle;
    },

    resetUI: function() {
        this.update("null");
    },

    initMenus: function() {
        $(".svMenu > li",this.container).bind("click", function(evt) {
            $(".SearchControls ul ul",this.container).css("display", "none").css("left","auto");
            $(this).find("ul")
                .css("display","block");
            var menu = $($(this).find("ul")[0]);
            var menuRight = menu.offset().left + menu.width();
            var delta = menu.offset().left - menu.position().left;
            if (menuRight > $(window).width()) {
                menu.css("left",$(window).width()-menu.width()-2 - delta );
            } else {
                menu.css("left","auto");
            }
            evt.stopPropagation();
            evt.preventDefault();
            return false;
        });
        $(document).click(function() {
            $(".SearchControls ul ul",this.container).css("display", "none");
        });
    },

    hideMenus: function() {
        $(".SearchControls ul ul").css("display", "none");
    },

    onContextChange: function(context) {
        var context = context || this.getContext();
        var job = this.getCurrentJob(context);
        if (job && !job.isDone()) {
            this.update("progress");
            $("a.unpause", this.container).removeClass("unpause").addClass("pause");
        }
        
    },

    update: function(newState) {
        if (this.state && this.state==newState) {
            return;
        }
        this.stateWrapper
            .removeClass(this.state + "State")
            .addClass(newState + "State");
        this.state = newState;
        if (this.getParam("cssClass")) {
            var context = this.getContext();
            Sideview.utils.setStandardTimeRangeKeys(context);
            Sideview.utils.setStandardJobKeys(context, true);
            Sideview.utils.applyCustomCssClass(this,context);
        }
        
    },

    /**
     * 
     */
    onJobProgress: function() {
        if (this.state=="paused") return;
        this.update("progress");
    },

    /**
     * 
     */
    onJobDone: function() {
        this.update("done");
    }
});
