// Copyright (C) 2010-2015 Sideview LLC.  All Rights Reserved.

if (typeof(Sideview)!="undefined") {
    var jqueryVersion = $.fn.jquery;
    var splunkVersion = Sideview.utils.getConfigValue("VERSION_LABEL");
    if (Sideview.utils.compareVersions(splunkVersion,"6") == -1) {
        $.fn.extend({
            delegate: function( selector, types, data, fn ) {
                return this.live( types, data, fn, selector );
            }
        });
    }
}


Splunk.Module.CheckboxPulldown= $.klass(Sideview.utils.getBaseClass(true), {

    initialize: function($super, container) {
        $super(container);
        this.logger = Sideview.utils.getLogger();
        this.name = this.getParam("name");
        this.searchFields = this.getSearchFields();
        
        this.staticFields = this.getParam("staticOptions") || [];
        this.nullTemplate = this.getParam("nullTemplate");
        // we use this flag to keep track of whether we're still loading data.
        this.inFlight = this.searchFields.length > 0;
        this.hasClearedURLLoader = false;

        this.unSelectedValues = {}

        this.select = $('select', this.container)
            .bind("change", this.onChange.bind(this));
        
        // local properties used if/when we display progress
        this.selectWidth  = 0;
        this.progressBar  = $(".progressTop", this.container);

        this.setFloatingBehavior();
        this.checkConfig();
        
        Sideview.utils.applyCustomProperties(this);
        
        this.hitWithPrettyStick();
        
    },

    getSearchFields: function() {
        if (this.getParam("valueField")) {
            var obj = {};
            obj.value = this.getParam("valueField");
            if (this.getParam("labelField")) {
                obj.label = this.getParam("labelField");
            }
            return [obj];
        }
        return []
    },

    /**
     * certain template params are encoded such that '+' signs are interpreted
     * as spaces.  This is to workaround a problem in splunk's view config 
     * system whereby leading and trailing spaces get trimmed on module params
     */
    getParam: function($super, name) {
        if (name=="outerTemplate" || name=="separator") {
            var orig = $super(name);
            if (!orig) return orig;
            return Sideview.utils.replacePlusSigns(orig);
        }
        return $super(name);
    },

    /**
     * overall function to check for configuration errors.
     */
    checkConfig: function() {
        this.checkNameConfig();
        this.checkFieldsConfig();
        this.checkMultipleSelectionConfig();
    },

    /**
     * make sure the 'name' param is OK.
     */
    checkNameConfig: function() {
        if (this.name=="search") alert(this.moduleType + " Error - you do not want to set CheckboxPulldown's 'name' param to a value of 'search' as this will disrupt underlying functionality in Splunk.");
    },
    
    /**
     * make sure the fields params are OK.
     */
    checkFieldsConfig: function() {
        try {
            if (this.searchFields.length==0 && this.staticFields.length ==0) {
                alert("ERROR - CheckboxPulldown MUST be configured with at least one static option or with a valueField param to pull dynamic results.");
            } else if (this.staticFields.length==1 && this.searchFields.length==0) {
                alert("ERROR - CheckboxPulldown is configured statically but with only a single static option.");
            } else if (this.searchFields.length==0 && this.getParam("postProcess")) {
                alert("ERROR - CheckboxPulldown is configured with a postProcess param but no search fields. One of these is a mistake.");
            }
        } catch(e) {
            alert("ERROR - unexpected exception during CheckboxPulldown.checkFieldsConfig. Look for typos in the valueField, labelField or staticOptions params .");
            console.error(e);
        }
    },

    checkMultipleSelectionConfig: function() {
        if (!this.getParam("outerTemplate") || ("" + this.getParam("outerTemplate")).length==0) {
            alert("ERROR - you do not want to set CheckboxPulldown's outerTemplate param to an empty string as this means the CheckboxPulldown will never output any value besides emptystring. ");
        }
    },

    /**
     * sets floats and clears as determined by the config.
     */
    setFloatingBehavior: function() {
        // unfortunately a module's mako template cannot control its *own* 
        // container div.  So we are forced to float it here.
        if (this.getParam("float")) {
            $(this.container).css("margin-right", "10px");
            $(this.container).css("float", this.getParam("float"));
        }
        if (this.getParam("clear")) {
            $(this.container).css("clear", this.getParam("clear"));
        }
    },

    requiresResults: function() {
        return (this.searchFields.length>0);
    },

    requiresDispatch: function($super, search) {
        if (!this.requiresResults()) return false;
        else return $super(search);
    },

    /** 
     * see comment on DispatchingModule.requiresTransformedResults
     */
    requiresTransformedResults: function() {
        return true;
    },

    /**
     * If the configuration refers to a field, and we're triggering a dispatch, 
     * we tell the framework to put the field(s) into the requiredFields list 
     * on the job before it gets kicked off.
     */
    onBeforeJobDispatched: function(search) {
        var fields = [];
        if (this.searchFields.length>0) {
            var c = this.getContext().clone();
            c.set("name", this.getParam("name"));
            
            var value = Sideview.utils.replaceTokensFromContext(this.searchFields[0].value, c);
            var label = Sideview.utils.replaceTokensFromContext(this.searchFields[0].label, c);
            fields.push(value);
            if (label && fields.indexOf(label)==-1) {
                fields.push(label);
            }
        }
        if (Sideview.utils.mightNeedStatusBuckets(search)) {
            search.setMinimumStatusBuckets(1);
            search.setRequiredFields(fields);
        }
    },

    /** 
     * get a dictionary of our search fields. keys are 'label' and 'value'.
     */
    getFields: function() {
        if (this.searchFields.length>0) {
            var value = this.searchFields[0].value;
            var label = this.searchFields[0].label || value;

            // do a quick token replacement.
            var c = this.getContext().clone();
            c.set("name", this.name);
            value = Sideview.utils.replaceTokensFromContext(value, c);
            label = Sideview.utils.replaceTokensFromContext(label, c);

            return {
                "value" : value,
                "label" : label
            }
        }
        return {};
    },

    /** 
     * This template method in the module framework allows us to tell the 
     * framework that we are "not ready" and so it will defer the push of 
     * our data to downstream modules until we ARE ready.
     */
    isReadyForContextPush: function($super) {
        if (this.inFlight) return Splunk.Module.DEFER;
        return $super();
    },

    /**
     * tell the URLLoader that we've absorbed their value so they dont keep 
     * telling us (and reselecting the value) over and over.
     */
    clearURLLoader: function(context) {
        context = context || this.getContext();
        // only do this once 
        if (!this.hasClearedURLLoader && context.has("sideview.onSelectionSuccess")) {
            var callback = context.get("sideview.onSelectionSuccess");
            callback(this.name, this);
            this.hasClearedURLLoader = true;
        }
    },

    setSelection: function(val) {
        this.select.val(val);
        this.select.multiselect('refresh');

        if (val=="*") {
            this.checkAll();
        }
    },

    getUnselectedOptions: function() {
        var opts = {}
        $("option:not(:selected)",this.select).each(function() {
            opts[$(this).attr("value")] = 1;
        });
        return opts;
    },

    getSelectedOptions: function() {
        return $.extend({}, this.select.val());
        
    },

    rememberUnselectedOptions: function() {
        $.extend(this.unSelectedValues,this.getUnselectedOptions())
        var selectedOptions = this.getSelectedOptions();
        for (opt in selectedOptions) {
            if (selectedOptions.hasOwnProperty(opt)) {
                delete this.unSelectedValues[opt];
            }
        }
    },

    forgetSomeUnselectedOptions: function(opts) {
        var val;
        for (var i=0,len=opts.length;i<len;i++) {
            val = opts[i];
            if (this.unSelectedValues.hasOwnProperty(val)) {
                delete this.unSelectedValues[val];
            }
        }
    },

    //resetToDefault: function() {},

    resetUI: function() {},
    
    setToContextValue: function(c) {
        var value = c.get(this.name + ".rawValue") || c.get(this.name);
        if (!value && value!="") return;
        this.forgetSomeUnselectedOptions(value);
        this.setSelection(value);
    },

    /**
     * If this returns true, then the CheckboxPulldown will be allowed to reload its
     * dynamic options onContextChange.   Pulled out as its own method so that 
     * it can be easily overridden by customBehavior.
     */
    allowReload: function(context) {
        return (!this._previousResultURL || this._previousResultURL != this.getResultURL({})); 
    },

    reloadDynamicOptions: function(context) {
        
        // clear all the old dynamic options.
        this.clearDynamicOptions();
        
        // add in our 'Loading...' text.
        var loadingOption = $("<option>")
            .addClass("dynamic")
            .text(_("Loading..."))
            .attr("value","")
        
        this.select.append(loadingOption);
            
        this.selectWidth = this.getSelectWidth();
        
        // go get the fresh data.
        if (context.get("search").job.isDone()) {
            this.getResults();
        } else {
            this.inFlight = true;
        }
    },

    /**
     * called when a module from upstream changes the context data
     */
    onContextChange: function() {
        var context = this.getContext();
        Sideview.utils.applyCustomCssClass(this,context);
        // handles purely dynamic config as well as the mixed case. 
        if (this.searchFields.length>0 && this.allowReload(context)) {   
            this.reloadDynamicOptions(context);
            this._previousResultURL = this.getResultURL({});
        } 
        // purely static configuration, or dynamic config that doesn't need 
        // to be reloaded.
        else {
            this.setToContextValue(context);
            this.clearURLLoader(context);
        }
        // if the label param contains $foo$ tokens we rewrite the label accordingly
        if (this.getParam("label") && this.getParam("label").indexOf("$")!=-1) {
            context.set("name", this.getParam("name"));
            var labelTemplate = this.getParam("label");
            $("label", this.container).text(Sideview.utils.replaceTokensFromContext(labelTemplate, context));
        }
    },

    /**
     * Given all the template, size, separator, outerTemplate params we might 
     * be dealing with, what is the final string value to send downstream.
     */
    getStringValue: function(context) {
        var template = this.getParam("template");
        
        var values = this.select.val() || [];
        var templatizedValues = [];
        var templatizedValue;
        for (var i=0,len=values.length;i<len;i++) {
            if (!values[i] || values[i] == "") {
                if (this.nullTemplate) {
                    templatizedValue = Sideview.utils.safeTemplatize(context, this.nullTemplate, this.name, "*");
                }
                else {
                    continue;
                }
            }
            else {
                
                templatizedValue = Sideview.utils.safeTemplatize(context, template, this.name, values[i]);
            }
            templatizedValues.push(templatizedValue);
        }
        var separator = this.getParam("separator") || "";
        var gluedValue = templatizedValues.join(separator);
        var outerTemplate = this.getParam("outerTemplate");
        // we do not escape slashes in the outer template. It's not input 
        // from the user. And to the extent that other $foo$ tokens will
        // be in here, they will have been backslashed upstream.
        return Sideview.utils.templatize(context, outerTemplate, this.name, gluedValue);
        
    },

    getLabels: function() {
        var labels = []
        $('option:selected', this.select).each(function() {
            labels.push($(this).text());
        });
        return labels.join(", ")
    },

    /**
     * called when a module from downstream requests new context data
     */
    getModifiedContext: function(context) {
        var context = context || this.getContext();
        
        context.set(this.name + ".label", this.getLabels());
        context.set(this.name + ".element", Sideview.utils.makeUnclonable(this.select));
        // we do not backslash escape rawValue, because we assume it is NOT 
        // destined for searches.  rawValue is for QS args and for labels.
        context.set(this.name + ".rawValue", this.select.val());

        var value = this.getStringValue(context);
        context.set(this.name + ".value", value);
        context.set(this.name, value);

        return context;
    },
    
    /**
     * called when we have to send new context data to downstream modules.
     */
    pushContextToChildren: function($super, explicitContext) {
        val = this.select.val() || [];
        this._lastValue=val.join("-x-");
        /* see notes in Checkbox.js */
        this.withEachDescendant(function(module) {
            module.dispatchAlreadyInProgress = false;
        });
        return $super(explicitContext);
    },

    
    
    onPassiveChange: function() {
        var context = this.getContext();
        this.rememberUnselectedOptions();
        if (! this.ignoringSelectionChanges && context.has("sideview.onEditableStateChange")) {
            var callback = context.get("sideview.onEditableStateChange");
            callback(this.name, this.select.val(), this);
        }
    },
    
    /**
     * empty template method to make CustomBehavior use cases easier.
     */
    customOnChange: function(evt) {},

    /**
     * called when the user changes the CheckboxPulldown's selected value.
     */
    onChange: function(evt) {
        this.customOnChange(evt);

        if (this.isPageLoadComplete()) {
            this.onPassiveChange();
        }
        this.clearURLLoader();
    },

    /*********************************
     * Methods about showing job progress
     *********************************/
    getSelectWidth: function() {
        var w = this.select.width();
        w += parseInt(this.select.css("padding-left"));
        w += parseInt(this.select.css("padding-right"));
        return w;
    },
    renderProgress: function(p) {
        if (this.selectWidth<=7) {
            this.selectWidth = this.getSelectWidth();
        }
        this.progressBar.width(p * this.selectWidth);
        var offset = $("button.ui-multiselect",this.container).offset();
        this.progressBar.offset(offset);
    },
    onJobProgress: function() {
        if (this.searchFields.length>0) {
            this.progressBar.show();
            var search = this.getContext().get("search");
            this.renderProgress(search.job.getDoneProgress());
        }
    },

    /**
     * called when the currently running job completes.
     */
    onJobDone: function() {
        if (this.searchFields.length>0) {
            this.getResults();
        }
        $(".progressTop", this.container).hide();
    },

    /** 
     * template method we expose that is to be called after rendering completes. 
     * this greatly simplifies some custom wiring use cases.
     */
    onRendered: function() {

    },

    /**
     * Goes and gets new results that we'll turn into our <option> values.
     */
    getResults: function($super) {
        this.inFlight = true;

        return $super()
    },

    /**
     * returns the URL used by the module to GET its results.
     */
    getResultURL: function(params) {
        var context = this.getContext();
        var search  = context.get("search");
        // sadly the getUrl method has a bug where it doesnt handle params
        // properly in the 'results' endpoint.
        var url = search.getUrl("results");
        params["count"] = this.getParam("count");

        var upstreamPostProcess = search.getPostProcess();
        if (this.getParam("postProcess")) {
            // we sneak in our own name so it can be referred to 
            // as $name$ in the postProcess param's value
            context.set("name", this.name);
            context.set("postProcess", upstreamPostProcess || "");
            var p = Sideview.utils.replaceTokensFromContext(this.getParam("postProcess"), context);
            params["search"] = p;
        } else if (upstreamPostProcess) {
            params["search"] = upstreamPostProcess;
        }

        params["outputMode"] = "json";
        return url + "?" + Sideview.utils.dictToString(params);
    },

    clearDynamicOptions: function() {
        this.select.find("option[class=dynamic]").remove();
    },

    /**
     * We just use splunkWeb's proxy to splunkd, so the results will come back 
     * in JSON format.  This method builds out <option> elements from that JSON.
     */
    buildOptionListFromResults: function(jsonStr) {
        if (!jsonStr) {
            this.logger.warn("empty string returned in " + this.moduleType + ".renderResults ("+this.name+")");
            this.logger.debug(jsonStr);
            return;
        }
        // always returns a 2 element dictionary with 'label' and 'value'.
        var fieldDict = this.getFields();

        var results = Sideview.utils.getResultsFromJSON(jsonStr);
        var row, value, label;
        for (var i=0,len=results.length;i<len;i++) {
            row = results[i];
            value = row[fieldDict["value"]];
            label = row[fieldDict["label"]];
            if (!value && value!="") {
                if (label && !this.nullTemplate) {
                    label="(ERROR - null-valued option found, but required nullTemplate param is missing.)";
                } else {
                    this.logger.error("ERROR - a CheckboxPulldown (" + this.moduleId + ") received a result row that had no value for the value field (" + fieldDict["value"] + ").");
                    value="";
                    label="(no value found)";
                }
            }
            else if (!label && label!="") {
                this.logger.warn("CheckboxPulldown received a result row that had no value for the label field (" + fieldDict["label"] + ").  Using the value field instead (" + fieldDict["value"] + ").");
                label = value;
            }
            var opt = $("<option>")
                .addClass("dynamic")
                .text(label)
                .attr("value",value)
            if (!this.unSelectedValues.hasOwnProperty(value)) {
                opt.attr("selected","selected");
            }
            this.select.append(opt);
        };
        this.selectWidth = this.getSelectWidth();
    },
    
    getMultipleSelectArgs: function() {
        var args = {}
        args.multiple = true;
        args.header = true;
        args.minWidth = 190;
        args.selectedText = this.getSelectedTextLabel;
        args.close = function() {
            var val = this.select.val() || [];
            val = val.join("-x-");

            if (!this._lastValue || val!=this._lastValue) {
                this.pushContextToChildren();
            }
        }.bind(this);
        return args;
    },

    getSelectedTextLabel: function(checked,total,options) {
        if (checked==1) {
            return $(options[0]).attr("title");
        }
        else if (total==0) {
            return _("no options found");
        }
        else if (checked==total) {
            return sprintf(_("all %d selected"), total);
        }
        else {
            return sprintf(_("%d of %d selected"), checked,total);
        }
    },

    hitWithPrettyStick: function() {
        this.select.multiselect(this.getMultipleSelectArgs());
        // purely static CheckboxPulldowns with no 
        // <param name="selected">True</param> should select all by default
        var s = this.select.val() || []
        if (this.searchFields.length==0 && s.length==0) {
            this.checkAll();
        }
    },
    
    checkAll: function() {
        this.ignoringSelectionChanges = true;
        this.select.multiselect("checkAll");
        this.ignoringSelectionChanges = false;
    },

    show: function($super,visibilityReason) {
        var retVal = $super(visibilityReason);
        if ($.browser.msie && !this.getParam("width")) {
            this.select.css("width", "auto");
            this.selectWidth = this.getSelectWidth();
        }
        return retVal;
    },

    /** 
     * called each time we render our CheckboxPulldown data from the server.
     */
    renderResults: function(jsonStr) {
        var context = this.getContext();
        // remember which value was selected before.

        
        
        // clear the old dynamic options again. In practice this just clears 
        // out the 'Loading...' option because the others are already gone.
        this.clearDynamicOptions();

        var runSelectWidthPatchForIE = ($.browser.msie && !this.getParam("width"));
        if (runSelectWidthPatchForIE) {
            this.select.css("width", "auto");
        }
        this.buildOptionListFromResults(jsonStr);

        var value = context.get(this.name + ".rawValue") || context.get(this.name);

        if (value) {
            this.forgetSomeUnselectedOptions(value)
            this.clearURLLoader(context);
            this.setSelection(value);
        } else {
            this.select.multiselect('refresh');
        }


        this.inFlight = false;
        if (runSelectWidthPatchForIE) {
            this.select.width(this.select.width()+10);
        }
        this.onRendered();
        this.pushContextToChildren();
    },

    getResultsErrorHandler: function(xhr, textStatus, errorThrown) {
        this.resetXHRStatus();
        if (textStatus == 'abort') {
            this.logger.debug(this.moduleType, '.getResults() aborted');
        } else {
            try {
                this.logger.error(this.moduleType, " error response from server. status=" + xhr.status);
                var messages = JSON.parse(xhr.responseText).messages;
                for (var i=0;i<messages.length;i++) {
                    this.logger.error(messages[i].message);
                }
            } catch(e) {
                this.logger.error(this.moduleType, " exception thrown trying to log an error from the server.");
                this.logger.error(xhr.responseText);
            }
        }
    }, 

    /**
     * called when a module receives new context data from downstream. 
     * This is rare, and only happens in configurations where custom behavior
     * logic is sending values upstream during interactions, for TextField
     * and CheckboxPulldown instances to 'catch'. 
     */
     applyContext: function(context) {
        if (!this.isPageLoadComplete()) {
            this.logger.error(this.moduleType + " is not designed to work with the oldschool Search resurrection system.");
        }
        if (this.isPageLoadComplete() && context.has(this.name)) {
            var oldValue = this.select.val();
            var newValue = context.get(this.name);
            this.select.val(newValue);
            if (this.select.val() == newValue) {
                context.remove(this.name);
                this.onPassiveChange();
                

                var search = context.get("search");
                
                context.remove("search");
                if (!search.hasIntentions() && Sideview.utils.contextIsNull(context)) {
                    this.pushContextToChildren();
                    // stop the upward-travelling context.
                    return true;
                }
                context.set("search",search);

            } else {
                this.select.val(oldValue);
            }
        }
     }
});


/*
 * This is licensed from Eric Hynds via the MIT license. 
 * Some subsequent fixes have been made by Sideview, LLC, including
 * changes to make the component work when values contain html-unsafe
 * characters.

 * jQuery MultiSelect UI Widget 1.13
 * Copyright (c) 2012 Eric Hynds
 *
 * http://www.erichynds.com/jquery/jquery-ui-multiselect-widget/
 *
 * Depends:
 *   - jQuery 1.4.2+
 *   - jQuery UI 1.8 widget factory
 *
 * Optional:
 *   - jQuery UI effects
 *   - jQuery UI position utility
 *
 * Dual licensed under the MIT and GPL licenses:
 *   http://www.opensource.org/licenses/mit-license.php
 *   http://www.gnu.org/licenses/gpl.html
 *
 */
(function($, undefined){

var multiselectID = 0;

$.widget("ech.multiselect", {

	// default options
	options: {
		header: true,
		height: 175,
		minWidth: 225,
		classes: '',
		checkAllText: 'Check all',
		uncheckAllText: 'Uncheck all',
		noneSelectedText: 'Select options',
		selectedText: '# selected',
		selectedList: 0,
		show: null,
		hide: null,
		autoOpen: false,
		multiple: true,
		position: {}
	},

	_create: function(){
		var el = this.element.hide(),
			o = this.options;

		this.speed = $.fx.speeds._default; // default speed for effects
		this._isOpen = false; // assume no

		var
			button = (this.button = $('<button type="button"><span class="ui-icon ui-icon-triangle-2-n-s"></span></button>'))
				.addClass('ui-multiselect ui-widget ui-state-default ui-corner-all')
				.addClass( o.classes )
				.attr({ 'title':el.attr('title'), 'aria-haspopup':true, 'tabIndex':el.attr('tabIndex') })
				.insertAfter( el ),

			buttonlabel = (this.buttonlabel = $('<span />'))
				.html( o.noneSelectedText )
				.appendTo( button ),

			menu = (this.menu = $('<div />'))
				.addClass('ui-multiselect-menu ui-widget ui-widget-content ui-corner-all')
				.addClass( o.classes )
				.appendTo( document.body ),

			header = (this.header = $('<div />'))
				.addClass('ui-widget-header ui-corner-all ui-multiselect-header ui-helper-clearfix')
				.appendTo( menu ),

			headerLinkContainer = (this.headerLinkContainer = $('<ul />'))
				.addClass('ui-helper-reset')
				.html(function(){
					if( o.header === true ){
						return '<li><a class="ui-multiselect-all" href="#"><span class="ui-icon ui-icon-check"></span><span>' + o.checkAllText + '</span></a></li><li><a class="ui-multiselect-none" href="#"><span class="ui-icon ui-icon-closethick"></span><span>' + o.uncheckAllText + '</span></a></li>';
					} else if(typeof o.header === "string"){
						return '<li>' + o.header + '</li>';
					} else {
						return '';
					}
				})
				.append('<li class="ui-multiselect-close"><a href="#" class="ui-multiselect-close"><span class="ui-icon ui-icon-circle-close"></span></a></li>')
				.appendTo( header ),

			checkboxContainer = (this.checkboxContainer = $('<ul />'))
				.addClass('ui-multiselect-checkboxes ui-helper-reset')
				.appendTo( menu );

		// perform event bindings
		this._bindEvents();

		// build menu
		this.refresh( true );

		// some addl. logic for single selects
		if( !o.multiple ){
			menu.addClass('ui-multiselect-single');
		}
	},

	_init: function(){
		if( this.options.header === false ){
			this.header.hide();
		}
		if( !this.options.multiple ){
			this.headerLinkContainer.find('.ui-multiselect-all, .ui-multiselect-none').hide();
		}
		if( this.options.autoOpen ){
			this.open();
		}
		if( this.element.is(':disabled') ){
			this.disable();
		}
	},

	refresh: function( init ){
		var el = this.element,
			o = this.options,
			menu = this.menu,
			checkboxContainer = this.checkboxContainer,
			optgroups = [],
			html = "",
			id = el.attr('id') || multiselectID++; // unique ID for the label & option tags

		// build items
		el.find('option').each(function( i ){
			var $this = $(this),
				parent = this.parentNode,
				title = this.innerHTML,
				description = this.title,
				value = this.value,
				inputID = 'ui-multiselect-' + (this.id || id + '-option-' + i),
				isDisabled = this.disabled,
				isSelected = this.selected,
				labelClasses = [ 'ui-corner-all' ],
				liClasses = (isDisabled ? 'ui-multiselect-disabled ' : ' ') + this.className,
				optLabel;

			// is this an optgroup?
			if( parent.tagName === 'OPTGROUP' ){
				optLabel = parent.getAttribute( 'label' );

				// has this optgroup been added already?
				if( $.inArray(optLabel, optgroups) === -1 ){
                    li = $("<li>")
                        .addClass("ui-multiselect-optgroup-label")
                        .addClass(parent.className)
                        .append($("<a>")
                            .attr("href","#")
                            .text(optLabel)
                        );
					html += li.html();
                    //html += '<li class="ui-multiselect-optgroup-label ' + parent.className + '"><a href="#">' + optLabel + '</a></li>';
					optgroups.push( optLabel );
				}
			}

			if( isDisabled ){
				labelClasses.push( 'ui-state-disabled' );
			}

			// browsers automatically select the first option
			// by default with single selects
			if( isSelected && !o.multiple ){
				labelClasses.push( 'ui-state-active' );
			}
            
            var svInput = $("<input>")
                .attr("id",inputID)
                .attr("name","multiselect_" + id)
                .attr("type",(o.multiple ? "checkbox" : "radio"))
                .attr("value",value)
                .attr("title",title)


            if( isSelected ){
                svInput.attr("checked","checked");
                svInput.attr("aria-selected","true");
            }

            if( isDisabled ){
                svInput.attr("disabled","disabled");
                svInput.attr("aria-disabled","true");
            }


            svLi = $("<li>")
                .attr("class",liClasses)
                .append(
                     $("<label>")
                        .attr("for", inputID)
                        .attr("title", description)
                        .attr("class", labelClasses.join(' ')
                     )
                     .append(svInput)
                     .append($("<span>").text(title))
                )
                

            html += svLi.html();

		});

		// insert into the DOM
		checkboxContainer.html( html );

		// cache some moar useful elements
		this.labels = menu.find('label');
		this.inputs = this.labels.children('input');

		// set widths
		this._setButtonWidth();
		this._setMenuWidth();

		// remember default value
		this.button[0].defaultValue = this.update();

		// broadcast refresh event; useful for widgets
		if( !init ){
			this._trigger('refresh');
		}
	},

	// updates the button text. call refresh() to rebuild
	update: function(){
		var o = this.options,
			$inputs = this.inputs,
			$checked = $inputs.filter(':checked'),
			numChecked = $checked.length,
			value;

		if( numChecked === 0 ){
			value = o.noneSelectedText;
		} else {
			if($.isFunction( o.selectedText )){
				value = o.selectedText.call(this, numChecked, $inputs.length, $checked.get());
			} else if( /\d/.test(o.selectedList) && o.selectedList > 0 && numChecked <= o.selectedList){
				value = $checked.map(function(){ return $(this).next().html(); }).get().join(', ');
			} else {
				value = o.selectedText.replace('#', numChecked).replace('#', $inputs.length);
			}
		}

		this.buttonlabel.html( value );
		return value;
	},

	// binds events
	_bindEvents: function(){
		var self = this, button = this.button;

		function clickHandler(){
			self[ self._isOpen ? 'close' : 'open' ]();
			return false;
		}

		// webkit doesn't like it when you click on the span :(
		button
			.find('span')
			.bind('click.multiselect', clickHandler);

		// button events
		button.bind({
			click: clickHandler,
			keypress: function( e ){
				switch(e.which){
					case 27: // esc
					case 38: // up
					case 37: // left
						self.close();
						break;
					case 39: // right
					case 40: // down
						self.open();
						break;
				}
			},
			mouseenter: function(){
				if( !button.hasClass('ui-state-disabled') ){
					$(this).addClass('ui-state-hover');
				}
			},
			mouseleave: function(){
				$(this).removeClass('ui-state-hover');
			},
			focus: function(){
				if( !button.hasClass('ui-state-disabled') ){
					$(this).addClass('ui-state-focus');
				}
			},
			blur: function(){
				$(this).removeClass('ui-state-focus');
			}
		});

		// header links
		this.header
			.delegate('a', 'click.multiselect', function( e ){
				// close link
				if( $(this).hasClass('ui-multiselect-close') ){
					self.close();

				// check all / uncheck all
				} else {
					self[ $(this).hasClass('ui-multiselect-all') ? 'checkAll' : 'uncheckAll' ]();
				}

				e.preventDefault();
			});

		// optgroup label toggle support
		this.menu
			.delegate('li.ui-multiselect-optgroup-label a', 'click.multiselect', function( e ){
				e.preventDefault();

				var $this = $(this),
					$inputs = $this.parent().nextUntil('li.ui-multiselect-optgroup-label').find('input:visible:not(:disabled)'),
					nodes = $inputs.get(),
					label = $this.parent().text();

				// trigger event and bail if the return is false
				if( self._trigger('beforeoptgrouptoggle', e, { inputs:nodes, label:label }) === false ){
					return;
				}

				// toggle inputs
				self._toggleChecked(
					$inputs.filter(':checked').length !== $inputs.length,
					$inputs
				);

				self._trigger('optgrouptoggle', e, {
				    inputs: nodes,
				    label: label,
				    checked: nodes[0].checked
				});
			})
			.delegate('label', 'mouseenter.multiselect', function(){
				if( !$(this).hasClass('ui-state-disabled') ){
					self.labels.removeClass('ui-state-hover');
					$(this).addClass('ui-state-hover').find('input').focus();
				}
			})
			.delegate('label', 'keydown.multiselect', function( e ){
				e.preventDefault();

				switch(e.which){
					case 9: // tab
					case 27: // esc
						self.close();
						break;
					case 38: // up
					case 40: // down
					case 37: // left
					case 39: // right
						self._traverse(e.which, this);
						break;
					case 13: // enter
						$(this).find('input')[0].click();
						break;
				}
			})
			.delegate('input[type="checkbox"], input[type="radio"]', 'click.multiselect', function( e ){
				var $this = $(this),
					val = this.value,
					checked = this.checked,
					tags = self.element.find('option');

				// bail if this input is disabled or the event is cancelled
				if( this.disabled || self._trigger('click', e, { value: val, text: this.title, checked: checked }) === false ){
					e.preventDefault();
					return;
				}

				// make sure the input has focus. otherwise, the esc key
				// won't close the menu after clicking an item.
				$this.focus();

				// toggle aria state
				$this.attr('aria-selected', checked);

				// change state on the original option tags
				tags.each(function(){
					if( this.value === val ){
						this.selected = checked;
					} else if( !self.options.multiple ){
						this.selected = false;
					}
				});

				// some additional single select-specific logic
				if( !self.options.multiple ){
					self.labels.removeClass('ui-state-active');
					$this.closest('label').toggleClass('ui-state-active', checked );

					// close menu
					self.close();
				}

				// fire change on the select box
				self.element.trigger("change");

				// setTimeout is to fix multiselect issue #14 and #47. caused by jQuery issue #3827
				// http://bugs.jquery.com/ticket/3827
				setTimeout($.proxy(self.update, self), 10);
			});

		// close each widget when clicking on any other element/anywhere else on the page
		$(document).bind('mousedown.multiselect', function( e ){
			if(self._isOpen && !$.contains(self.menu[0], e.target) && !$.contains(self.button[0], e.target) && e.target !== self.button[0]){
				self.close();
			}
		});

		// deal with form resets.  the problem here is that buttons aren't
		// restored to their defaultValue prop on form reset, and the reset
		// handler fires before the form is actually reset.  delaying it a bit
		// gives the form inputs time to clear.
		$(this.element[0].form).bind('reset.multiselect', function(){
			setTimeout($.proxy(self.refresh, self), 10);
		});
	},

	// set button width
	_setButtonWidth: function(){
		var width = this.element.outerWidth(),
			o = this.options;

		if( /\d/.test(o.minWidth) && width < o.minWidth){
			width = o.minWidth;
		}

		// set widths
		this.button.width( width );
	},

	// set menu width
	_setMenuWidth: function(){
		var m = this.menu,
			width = this.button.outerWidth()-
				parseInt(m.css('padding-left'),10)-
				parseInt(m.css('padding-right'),10)-
				parseInt(m.css('border-right-width'),10)-
				parseInt(m.css('border-left-width'),10);

		m.width( width || this.button.outerWidth() );
	},

	// move up or down within the menu
	_traverse: function( which, start ){
		var $start = $(start),
			moveToLast = which === 38 || which === 37,

			// select the first li that isn't an optgroup label / disabled
			$next = $start.parent()[moveToLast ? 'prevAll' : 'nextAll']('li:not(.ui-multiselect-disabled, .ui-multiselect-optgroup-label)')[ moveToLast ? 'last' : 'first']();

		// if at the first/last element
		if( !$next.length ){
			var $container = this.menu.find('ul').last();

			// move to the first/last
			this.menu.find('label')[ moveToLast ? 'last' : 'first' ]().trigger('mouseover');

			// set scroll position
			$container.scrollTop( moveToLast ? $container.height() : 0 );

		} else {
			$next.find('label').trigger('mouseover');
		}
	},

	// This is an internal function to toggle the checked property and
	// other related attributes of a checkbox.
	//
	// The context of this function should be a checkbox; do not proxy it.
	_toggleState: function( prop, flag ){
		return function(){
			if( !this.disabled ) {
				this[ prop ] = flag;
			}

			if( flag ){
				this.setAttribute('aria-selected', true);
			} else {
				this.removeAttribute('aria-selected');
			}
		};
	},

	_toggleChecked: function( flag, group ){
		var $inputs = (group && group.length) ?  group : this.inputs,
			self = this;

		// toggle state on inputs
		$inputs.each(this._toggleState('checked', flag));

		// give the first input focus
		$inputs.eq(0).focus();

		// update button text
		this.update();

		// gather an array of the values that actually changed
		var values = $inputs.map(function(){
			return this.value;
		}).get();

		// toggle state on original option tags
		this.element
			.find('option')
			.each(function(){
				if( !this.disabled && $.inArray(this.value, values) > -1 ){
					self._toggleState('selected', flag).call( this );
				}
			});

		// trigger the change event on the select
		if( $inputs.length ) {
			this.element.trigger("change");
		}
	},

	_toggleDisabled: function( flag ){
		this.button
			.attr({ 'disabled':flag, 'aria-disabled':flag })[ flag ? 'addClass' : 'removeClass' ]('ui-state-disabled');

		var inputs = this.menu.find('input');
		var key = "ech-multiselect-disabled";

		if(flag) {
			// remember which elements this widget disabled (not pre-disabled)
			// elements, so that they can be restored if the widget is re-enabled.
			inputs = inputs.filter(':enabled')
				.data(key, true)
		} else {
			inputs = inputs.filter(function() {
				return $.data(this, key) === true;
			}).removeData(key);
		}

		inputs
			.attr({ 'disabled':flag, 'arial-disabled':flag })
			.parent()[ flag ? 'addClass' : 'removeClass' ]('ui-state-disabled');

		this.element
			.attr({ 'disabled':flag, 'aria-disabled':flag });
	},

	// open the menu
	open: function( e ){
		var self = this,
			button = this.button,
			menu = this.menu,
			speed = this.speed,
			o = this.options,
			args = [];

		// bail if the multiselectopen event returns false, this widget is disabled, or is already open
		if( this._trigger('beforeopen') === false || button.hasClass('ui-state-disabled') || this._isOpen ){
			return;
		}

		var $container = menu.find('ul').last(),
			effect = o.show,
			pos = button.offset();

		// figure out opening effects/speeds
		if( $.isArray(o.show) ){
			effect = o.show[0];
			speed = o.show[1] || self.speed;
		}

		// if there's an effect, assume jQuery UI is in use
		// build the arguments to pass to show()
		if( effect ) {
      args = [ effect, speed ];
		}

		// set the scroll of the checkbox container
		$container.scrollTop(0).height(o.height);

		// position and show menu
		if( $.ui.position && !$.isEmptyObject(o.position) ){
			o.position.of = o.position.of || button;

			menu
				.show()
				.position( o.position )
				.hide();

		// if position utility is not available...
		} else {
			menu.css({
				top: pos.top + button.outerHeight(),
				left: pos.left
			});
		}

		// show the menu, maybe with a speed/effect combo
		$.fn.show.apply(menu, args);

		// select the first option
		// triggering both mouseover and mouseover because 1.4.2+ has a bug where triggering mouseover
		// will actually trigger mouseenter.  the mouseenter trigger is there for when it's eventually fixed
		this.labels.eq(0).trigger('mouseover').trigger('mouseenter').find('input').trigger('focus');

		button.addClass('ui-state-active');
		this._isOpen = true;
		this._trigger('open');
	},

	// close the menu
	close: function(){
		if(this._trigger('beforeclose') === false){
			return;
		}

		var o = this.options,
		    effect = o.hide,
		    speed = this.speed,
		    args = [];

		// figure out opening effects/speeds
		if( $.isArray(o.hide) ){
			effect = o.hide[0];
			speed = o.hide[1] || this.speed;
		}

    if( effect ) {
      args = [ effect, speed ];
    }

    $.fn.hide.apply(this.menu, args);
		this.button.removeClass('ui-state-active').trigger('blur').trigger('mouseleave');
		this._isOpen = false;
		this._trigger('close');
	},

	enable: function(){
		this._toggleDisabled(false);
	},

	disable: function(){
		this._toggleDisabled(true);
	},

	checkAll: function( e ){
		this._toggleChecked(true);
		this._trigger('checkAll');
	},

	uncheckAll: function(){
		this._toggleChecked(false);
		this._trigger('uncheckAll');
	},

	getChecked: function(){
		return this.menu.find('input').filter(':checked');
	},

	destroy: function(){
		// remove classes + data
		$.Widget.prototype.destroy.call( this );

		this.button.remove();
		this.menu.remove();
		this.element.show();

		return this;
	},

	isOpen: function(){
		return this._isOpen;
	},

	widget: function(){
		return this.menu;
	},

	getButton: function(){
	  return this.button;
  },

	// react to option changes after initialization
	_setOption: function( key, value ){
		var menu = this.menu;

		switch(key){
			case 'header':
				menu.find('div.ui-multiselect-header')[ value ? 'show' : 'hide' ]();
				break;
			case 'checkAllText':
				menu.find('a.ui-multiselect-all span').eq(-1).text(value);
				break;
			case 'uncheckAllText':
				menu.find('a.ui-multiselect-none span').eq(-1).text(value);
				break;
			case 'height':
				menu.find('ul').last().height( parseInt(value,10) );
				break;
			case 'minWidth':
				this.options[ key ] = parseInt(value,10);
				this._setButtonWidth();
				this._setMenuWidth();
				break;
			case 'selectedText':
			case 'selectedList':
			case 'noneSelectedText':
				this.options[key] = value; // these all needs to update immediately for the update() call
				this.update();
				break;
			case 'classes':
				menu.add(this.button).removeClass(this.options.classes).addClass(value);
				break;
			case 'multiple':
				menu.toggleClass('ui-multiselect-single', !value);
				this.options.multiple = value;
				this.element[0].multiple = value;
				this.refresh();
		}

		$.Widget.prototype._setOption.apply( this, arguments );
	}
});

})(jQuery);


