
(function() {
    
  Splunk.Module.loadParams = {};
  Splunk.util.normalizeBoolean = Sideview.utils.normalizeBoolean;
  Splunk.util.isInt = Sideview.utils.isInteger;
  Splunk.util.make_url = Sideview.utils.make_url;
  Splunk.util.getConfigValue = Sideview.utils.getConfigValue;
  Splunk.util.getRetryInterval = function(){return 1000}
  Splunk.util.parseDate = Sideview.utils.parseDate;
  Splunk.util.getTimezoneOffsetDelta = Sideview.utils.getTimezoneOffsetDelta;
  
  Splunk.util.trim = $.trim;
  Splunk.Globals["Jobber"].JOB_MGMT_ENDPOINT = Sideview.utils.make_url("/api/search/jobs");

  // various crap needed for jschart
  Splunk.util.propToQueryString = Sideview.utils.dictToString;
  Splunk.util.normalizeColor = function(foo) {console.log("normalizeColor not implemented " + foo)}
  Splunk.util.getEpochTimeFromISO = function(isoStr) {console.log("iso time ftl")};
  Splunk.util.stringToFieldList = function(str) {if (str) return str.split(","); else return []}
  if (!String.prototype.rsplit) {
    String.prototype.rsplit = function(sep, maxsplit) {
      var split = this.split(sep);
      return maxsplit ? [ split.slice(0, -maxsplit).join(sep) ].concat(split.slice(-maxsplit)) : split;
    }
  }


    getSplunkFormKey = function() {
        //var port = document.location.port;
        var port = Sideview.utils.getConfigValue('MRSPARKLE_PORT_NUMBER', '')
        var name = "splunkweb_csrf_token_" + port;
        return $.cookie(name ) || "";
    }

    $.ajaxSetup({
        headers: { "X-Splunk-Form-Key": getSplunkFormKey() }
    });
    jQuery.ajaxSettings.traditional = true;

    Splunk.Globals["timeZone"] = new Splunk.TimeZone(Sideview.utils.getConfigValue('SERVER_ZONEINFO'));
    

    for (var i=0,len=Splunk.Module.modules.length;i<len;i++) {
        var wob = Splunk.Module.modules[i];
        if (wob.moduleName=="AccountBar" || wob.moduleName=="AppBar") {
            Splunk.Module.modules.splice(i, 1);
            len--;
            i--;
            continue;
        }
        Splunk.Module.loadParams[wob.id] = wob;

        var container = $("div#" + wob.id);
        
        var m = new Splunk.Module[wob.moduleName](container);
        m.moduleType = wob.moduleName;
        Splunk.Module.modules[i].obj = m

    }
    
    for (var i=0,len=Splunk.Module.modules.length;i<len;i++) {
        var m = Splunk.Module.modules[i];

        if (m.hasOwnProperty("parentId") && m["parentId"]) {
            var parent = Splunk.Module.loadParams[m.parentId];
            parent.obj.addChild(m.obj);
        }
    }
    for (var i=0,len=Splunk.Module.modules.length;i<len;i++) {
        try {
            Splunk.Module.modules[i].obj.onHierarchyLoaded();
        }
        catch (e) {
            alert(Splunk.Module.modules[i].moduleName + " has no instance");
        }
    }

    for (var i=0,len=Splunk.Module.modules.length;i<len;i++) {
        var m = Splunk.Module.modules[i];
        m.obj.markPageLoadComplete();
        if (m.obj.getParam("autoRun") == "True") {
            m.obj.pushDownstream();
        }
    }
    
    if (Splunk.Jobber) {
        
        Splunk.Globals["Jobber"].setClearedForPolling(true);
    }
}());











