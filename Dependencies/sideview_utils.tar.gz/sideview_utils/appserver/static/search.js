
Sideview.SplunkSearch = $.klass({
    initialize: function(str, timeRange) {
        this.str= str;
        this.timeRange = timeRange || new Splunk.TimeRange();
        // not crazy about it, but some legacy Splunk modules 
        // actually use an old private property name instead of 
        // the getter method. So to keep them creaking along 
        // we have to preserve that old reference .
        this._range = this.timeRange;

        this.statusBuckets = 0;
        this.requiredFields = [];
        this.selectedEventCount = -1;
        this.selectedEventAvailableCount = -1;
        this.timeRangeIsSubRangeOnBucketBoundary = false;
        this.preview = false;
        //this.maxTime = null;
        //this.sid = null;
        //this.postProcess = null;
        
    },
    

    clone: function() {
        var s = new Splunk.Search(this.str, this.timeRange.clone());

        s.statusBuckets = this.statusBuckets;
        s.requiredFields = $.extend([],this.requiredFields);
        s.selectedEventCount = this.selectedEventCount;
        s.selectedEventAvailableCount = this.selectedEventAvailableCount;

        s.maxTime = this.maxTime;
        s.sid = this.sid;
        if (this.job) s.job = this.job;
        s.postProcess = this.postProcess;

        s.preview = this.preview;
        return s;
    },


    isJobDispatched: function() {
        return !!this.sid;
    },

    toString: function() {
        return this.str;
    },
    setBaseSearch: function(str) {
        this.str = str;
    },
    setSavedSearchName: function(name) {
        this.savedSearchName = name;
    },
    getSavedSearchName: function() {
        this.savedSearchName;
    },
    getPostProcess: function() {
        return this.postProcess;
    },
    setPostProcess: function(str) {
        this.postProcess = str;
    },
    getMinimumStatusBuckets: function() {
        return this.statusBuckets;
    },
    setMinimumStatusBuckets: function(statusBuckets) {
        if (statusBuckets > this.statusBuckets) {
            this.statusBuckets = statusBuckets;
        }
    },
    getRequiredFields: function() {
        return this.requiredFields;
    },
    setRequiredFields: function(fields) {
        fields = $.extend([], fields);

        if (this.requiredFields.length==1 && this.requiredFields[0]=="*") {
            return;
        }
        if (fields.length==1 && fields[0]=="*") {
            this.requiredFields = ["*"];
            return;
        }
        for (var i=0,len=fields.length; i<len; i++) {
            if (this.requiredFields.indexOf(fields[i])==-1) {
                this.requiredFields.push(fields[i]);
            }
        }
    },

    
    getUrl: function(endpoint, args) {
        args = args || {};
        if (!this.sid) throw  "getURL called on a search with no sid";
        var url = ["api","search","jobs", this.sid, endpoint];

        if (["events","summary","timeline"].indexOf(endpoint)!=-1) {
            // for these endpoints, the API can actually give us results 
            // matching just the matching timeslice.
            // note that the client code accepts the responsibility that the
            // timerange passed really IS an exact match for a bucket boundary.
            // splunk will fudge it if the match is not exact. =/
            var range = this.getTimeRange();
            if (range.isAbsolute() && this.timeRangeIsSubRangeOnBucketBoundary) {
                args["earliest_time"] = range.getEarliestTimeTerms();
                args["latest_time"]   = range.getLatestTimeTerms();
                args["output_time_format"] = Sideview.utils.getConfigValue("SEARCH_RESULTS_TIME_FORMAT");
            }
        }
        return Sideview.utils.make_url(url.join("/")) + "?" + Sideview.utils.dictToString(args);
    },
    getTimeRange: function() {
        return this.timeRange;
    },
    setTimeRange: function(range) {
        if (!this.timeRange.equalToRange(range)) this.setSavedSearchName();
        this.timeRange = range;
    },
    clearTimeRange: function() {
        this.timeRange = new Splunk.TimeRange();
        this.setSavedSearchName();
    },

    abandonJob: function() {
        this.sid = null;
        this.timeRangeIsSubRangeOnBucketBoundary = false;
        this.statusBuckets = 0;
        this.requiredFields = []; 
        this.selectedEventCount = -1;
        this.selectedEventAvailableCount = -1;
    },

    getJobReference: function() {
        var manifest = Splunk.Globals["Jobber"]._jobManifest;
        if (manifest.hasOwnProperty(this.sid)) {
            return manifest[this.sid];
        }
        else {
            var j = new Splunk.Job(this.str);
            j.setSearchId(this.sid);
            return j;
        }
    },

    getEventCount: function() {
        if (!this.sid) return 0;
        if (this.selectedEventCount != -1) return this.selectedEventCount;
        return this.job.getEventCount();
    },

    getEventAvailableCount: function() {
        if (this.selectedEventAvailableCount != -1) return this.selectedEventAvailableCount;
        return this.job.getEventAvailableCount();
    },
    setSelectedEventCount: function(count) {
        this.selectedEventCount = count;
    },
    setSelectedEventAvailableCount: function(count) {
        this.selectedEventAvailableCount = count;
    },

    getDispatchArgs: function() {
        var range = this.getTimeRange();
        // just sneaking in to remove our all/all because splunkd wont 
        // know what we're talking about.
        if (range._constructorArgs[0]=="all" || range._constructorArgs[1]=="all") {
            for (var i=0;i<2;i++) {
                if (range._constructorArgs[i]=="all") range._constructorArgs[i] = false;
            }
        }

        var args = {
            "auto_cancel"        : Sideview.utils.getAutoCancelInterval(),
            "earliest_time"      : range.getEarliestTimeTerms(),
            "latest_time"        : range.getLatestTimeTerms(),
            "label"              : this.getSavedSearchName(),
            "max_time"           : this.getMaxTime(),
            "preview"            : this.getPreview(),
            "search"             : Sideview.utils.addInitialCommandIfAbsent(this.str),
            "status_buckets"     : this.getMinimumStatusBuckets(),
            "namespace"          : Sideview.utils.getCurrentApp(),
            "ui_dispatch_app"    : Sideview.utils.getCurrentApp(),
            "ui_dispatch_view"   : Sideview.utils.getCurrentDisplayView(),
            "wait": 0
        };
        if (range.getAbsoluteEarliestTime() || range.getAbsoluteLatestTime()) {
            args["timeFormat"] = Sideview.utils.getConfigValue("DISPATCH_TIME_FORMAT");
        }

        var nonNullArgs = ["adhoc_search_level","auto_finalize_ec","label","max_count","max_time","preview"];
        for (var i=0,len=nonNullArgs.length;i<len;i++) {
            if (!args[nonNullArgs[i]]) {
                delete args[nonNullArgs[i]];
            }
        }
        var fields = this.getRequiredFields();
        if (fields.length > 0) {
            args["required_field_list"] = fields.join(",");
        }
        return args;
    },

    dispatchCallback: function(data, onSuccess, onFailure, optionalMonitor) {
        if (data["success"] && data["data"]) {
            this.sid = data["data"];
            this.job = this.getJobReference();
            onSuccess(this);
            // what to do with markAutoCancellable 
            // what to do with setCreateTime
            $(document).trigger("jobDispatched", [this.job]);
            if (optionalMonitor) optionalMonitor.loadComplete();
        } 
        else if (!data["success"]) {
            if (this.messenger) {
                if (data.hasOwnProperty("messages")) {
                    for (var i=0,len=data["messages"].length; i<len; i++) {
                        var m = data["messages"][i];
                        var className = (m["type"]=="FATAL") ? "splunk.services" : "splunk.search.job";
                        this.messenger.send(m["type"].toLowerCase(), className, m["message"]);
                    }
                } else {
                    this.messenger.send("fatal", "splunk.search.job", 
                        _("Splunkd failed to dispatch a search but no messages came back on the response.")
                    );
                }
            }
            if (onFailure) onFailure(this);
        } 
        else {
            if (this.messenger) {
                this.messenger.send("fatal", "splunk.search.job", _("Received a successful response from a dispatch POST but no sid:"));
            }
            if (onFailure) onFailure(this);
        }
    },
    
    dispatchJob: function(onSuccess, onFailure) {
        if (this.timeRangeIsSubRangeOnBucketBoundary) {
            this.abandonJob();
        }

        var statusMonitor = false;
        if (Splunk.Globals.hasOwnProperty("PageStatus")) {
            statusMonitor = Splunk.Globals["PageStatus"].register("dispatching new job.");
        }
        
        $.post(
            Sideview.utils.make_url("/api/search/jobs"),
            this.getDispatchArgs(),
            function(data) {
                this.dispatchCallback(data,onSuccess, onFailure, statusMonitor);
            }.bind(this),
            "json"
        );
    },

    setPreview: function(preview) {
        if (!{"true":1,"false":1,"auto":1}.hasOwnProperty(preview)) {
            this.logger.error("Someone tried to set an illegal value for the preview arg - " + preview);
            return;
        }
        this.preview = preview;
    },

    getPreview: function() {
        return this.preview || false;
    },
    setMaxTime: function(t) {
        this.maxTime = t;
    },
    getMaxTime: function() {
        return this.maxTime;
    },
    getIntentionReference: function() {
        return false;
    },


});

Splunk.Search = Sideview.SplunkSearch;
Splunk.Search.hammerDontHurtEm = true;
