


Sideview.Module = $.klass({
    initialize: function(container, params) {
        this.container = $(container);
        this.moduleId = container.attr("id");
        this.parent = null;
        this._children = [];
        this._invisibilityModes = {};
        this._params = {}
        this.getResultsXHR = null;
        this.searchLastDispatchedHere = null;
        this.dispatchAlreadyInProgress = false;
        this.loadParams();
        this.resultsContainer = $("<div>").appendTo(this.container);
        // MUST FIX.only the dispatch points care,  so find a way to only attach to them.
        this.setupJobEventHandlers();
    },

    /************
      LOADING
     ***********/
    loadParams: function() {
        if (Splunk.Module.loadParams.hasOwnProperty(this.moduleId)) {
            this._params = Splunk.Module.loadParams[this.moduleId];
        }
    },
    

    isPageLoadComplete: function() {
        return this._pageLoadComplete || false;
    },
    markPageLoadComplete: function() {
        this._pageLoadComplete = true;
    },
    // stub.  This part of the old framework is all dead now.
    getLoadState: function() {
        return Sideview.utils.moduleLoadStates.WAITING_FOR_CONTEXT
    },

    /************
      EVENT HANDLERS
     ***********/
    setupJobEventHandlers: function() {
        var that = this;
        $(document).bind("jobProgress", function(evt, job) {
            //only the dispatch points listen.
            if (!that.searchLastDispatchedHere) return;
            var sid = that.searchLastDispatchedHere.sid;
            if (sid != job.getSearchId()) return;
            that.updateDownstreamContexts();
            that.withEachDescendantInDispatchTier(function(descendant) {
                descendant.onJobProgress(evt);
            });
        });

        $(document).bind("jobDone", function(evt, job) {
            //only the dispatch points listen.
            if (!that.searchLastDispatchedHere) return;
            var sid = that.searchLastDispatchedHere.sid;
            if (sid != job.getSearchId()) return;
            that.updateDownstreamContexts();
            that.withEachDescendantInDispatchTier(function(descendant) {
                descendant.onJobDone(evt);
            });
        });
        $(document).bind("jobStatusChanged", function(evt, sid, status) {
            var c = that.getContext();
            var s = c.get("search");
            if (sid != search.getSearchId()) return;
            if (status == 'cancel') that.reset();
        });
    },
    onHierarchyLoaded: function() {},
    onContextChange: function() {},
    onBeforeJobDispatched: function(search) {},
    onJobProgress: function(evt) {},
    onJobDone: function(evt) {},
    onResultsRendered: function() {},

    
    

    
    /************
     CORE CONTEXT METHODS
     ***********/


    updateChildContexts: function() {
        var c = this.getModifiedContext();
        if (this.searchLastDispatchedHere) {
            //console.log(this.moduleId + " updateChildContexts is setting baseContext to our searchLastDispatchedHere, which has sid=" + this.searchLastDispatchedHere.job.getSearchId());
            c.set("search", this.searchLastDispatchedHere);
        }
        for (var i=0,len=this._children.length; i<len;i++) {
            var child = this._children[i];
            child.baseContext = c.clone();
            if (!child.isPageLoadComplete()) {
                child.markPageLoadComplete();
            }
        }
        for (var i=0,len=this._children.length; i<len;i++) {
            var child = this._children[i];
        }
    },

    updateDownstreamContexts: function() {
        this.updateChildContexts();
        this.withEachDescendantInDispatchTier(function(module) {
            module.updateChildContexts();
        });
    },
    getNullContext: function() {
        var c = new Splunk.Context();
        var search = new Sideview.SplunkSearch();
        c.set("search", search);
        return c;
    },
    getContext: function() {
        return this.baseContext || this.getNullContext();
    },
    getModifiedContext: function() {
        return this.getContext();
    },

    pushContextToChildren: function() {
        console.log(this.moduleId + " legacy pushContextToChildren,  calling pushDownstream which may push");
        this.pushDownstream();
    },

    areWeAllowedToPush: function() {
        var ready = this.isReadyForContextPush()
        switch (ready) {
            case Splunk.Module.CANCEL:
                console.log(this.moduleId + " " + this.moduleType + " is not pushing because we're blocking");
                return ready;
            case Splunk.Module.DEFER :
                console.log(this.moduleId + " " + this.moduleType + " is not pushing because we hit a DEFER");
                // THE MODULE HAS A CONTRACT TO PUSH LATER. 
                // NOTE THAT WE ENFORCE NOTHING. HONOR SYSTEM FTW.
                return ready;
            case Splunk.Module.CONTINUE:
                break;
            default:
                throw("illegal return from isReadyForContextPush - " + ready );
        }

        var search  = (this.useDispatchedSearchOnNextPush) ? this.searchLastDispatchedHere : this.getModifiedContext().get("search");
        this.useDispatchedSearchOnNextPush = false;

        if (!search.isJobDispatched() && this.childrenRequireDispatch(search)) {
            search.abandonJob();
            this.withEachDescendant(function(module) {
                module.onBeforeJobDispatched(search);
            });
            this.dispatchJob(search);
            return Splunk.Module.DEFER;
        }
        return Splunk.Module.CONTINUE;
    },
    pushDownstream: function() {

        // right now it's logic inside areWeAllowedToPush that calls dispatchJob
            
        if (this.areWeAllowedToPush() == Splunk.Module.CONTINUE) {
            this.updateChildContexts();

            this.withEachChild(function(child) {
                child.onContextChange();
                child.pushDownstream();
            });
        }
    },

    isReadyForContextPush: function() {
        return Splunk.Module.CONTINUE;
    },
    
    applyContext: function() {},

    passContextToParent: function(context) {
        if (this.parent) {
            if (!this.isPageLoadComplete()) {
                throw("applyContext is illegal while page loading. Sideview XML does not support any kind of 'resurrection' or intention recomposition");
            }
            // we stop at the first return true
            if (!this.parent.applyContext(context)) {
                return this.parent.passContextToParent(context);
            } 
        } 
        return false;
    },

    /************
      DISPATCHING
     ***********/
    requiresResults: function() {return false;},
    requiresTransformedResults: function() {return false;},

    requiresDispatch: function(s) {
        if (!this.requiresResults()) return false;
        s = s || new Sideview.SplunkSearch();
        if (this.requiresTransformedResults()) {
            if (s.getTimeRange().isSubRangeOfJob()) {
                return true;
            }
        }
        try {
            return !s.isJobDispatched();
        } catch(e) {
            throw (this.moduleType, ".requiresDispatch() search threw an exception. " + e);
        }
    },
    _fireDispatch: function(search) {
        console.warn("legacy method name of _fireDispatch is deprecated")
        return this.dispatchJob(search);
    },
    dispatchJob: function(search) {
        if (!search) {
            //this.logger.error("ERROR - dispatchJob was not passed a search argument");
            return;
        }
        if (this.dispatchAlreadyInProgress) {
            return false;
        } else {
            this.dispatchAlreadyInProgress = true;
            search.dispatchJob(this.dispatchSuccess.bind(this), this.dispatchFailure.bind(this));
        }
    },

    dispatchSuccess: function(search) {
        this.dispatchAlreadyInProgress = false;
        var context = this.getModifiedContext();
        context.set("search", search);
        this.withEachDescendant(function(module) {
            module.reset();
        });
        if (this.searchLastDispatchedHere && this.searchLastDispatchedHere.isJobDispatched()) {
            this.searchLastDispatchedHere.job.cancel();
            console.warn("job cancellation is still not entirely thought through.");
        }
        this.searchLastDispatchedHere = search.clone();
        this.useDispatchedSearchOnNextPush = true;
        
        this.pushDownstream(context);
    },
    
    dispatchFailure: function(search) {
        this.dispatchAlreadyInProgress = false;
        this.withEachDescendant(function(module) {
            module.reset();
        });
    },

    childrenRequireDispatch: function(search) {
        var requireDispatch = false;
        this.withEachChild(function(child) {
            if (child.requiresDispatch(search)) {
                requireDispatch = true;
                return false;
            }
        });
        return requireDispatch;
    },



    /************
      GETTING RESULTS
     ***********/
    getResultURL: function(params) {
        var url = Sideview.utils.make_url("module", "system", this.moduleType, "render");
        params = params || {};
        url += "?" + Sideview.utils.dictToString(params);
        return url;
    },

    getResultParams: function () {
        return {};
    },

    haveResultParamsChanged: function() {
        var params = this.getResultParams();
        if (!this._previousResultParams) return true;
        return (!Sideview.utils.compareObjects(this._previousResultParams, params));
    },

    getResultsFailure: function(xhr, textStatus, errorThrown) {
        this.resetXHR();
        if (textStatus == "abort") {
            this.logger.debug(this.moduleType, ".getResults() aborted");
        } else {
            this.logger.warn(this.moduleType, ".getResults() error; textStatus=" + textStatus + " errorThrown=" + errorThrown);
        }
    },
    getResultsSuccess: function(response, textStatus, xhr) {
        if (xhr.status==0) {
            return;
        }
        this.renderResults(response);
        this.resetXHR();
    },
    getResultsComplete: function(xhr, textStatus) {
        this.resetXHR();
    },
    getResults: function() {
        if (this.getResultsXHR) {
            if (this.getResultsXHR.readyState < 4) {

            } else {
                this.resetXHR();
            }
        }
        var params = this.getResultParams();
        
        this._previousResultParams = $.extend(true, {}, params);

        var resultURL = this.getResultURL(params);
        if (!resultURL) {
            throw("getResultURL returned invalid URL - " + resultURL);
        }
        var moduleClass = this.moduleType;
        
        this.getResultsXHR = $.ajax({
            type: "GET",
            url: resultURL,
            cache: ($.browser.msie ? false : true),
            beforeSend: function(xhr) {
                xhr.setRequestHeader("X-Splunk-Module", moduleClass);
            },
            success:  this.getResultsSuccess.bind(this),
            error:    this.getResultsFailure.bind(this),
            complete: this.getResultsComplete.bind(this)
        });
    },
    /************
      RENDERING
     ***********/

    renderResults: function(response) {
        this.container.html(response);
        this.onResultsRendered();
    },
    /** 
     * grouped under rendering because in the SIdeview world this is just an 
     * item for Switcher and Table Embedding.
     */
    getGroupName : function() {
        return "";
    },


    
    /************
      RESETTING
     ***********/
    reset: function() {
        this.resetXHR();
        this.resetUI();
    },
    resetXHR: function() {
        this.getResultsXHR = null;
    },
    resetUI: function () {},


    /************
      TREE METHODS
     ***********/
    withEachAncestor: function(fn, reverse) {
        var ancestors = this.getAncestors();
        if (reverse) ancestors.reverse();
        for(var i=0, j=ancestors.length; i<j; i++) {
            var retVal = fn(ancestors[i]);
            if (retVal === false) return false;
        }
        return true;
    },
    withEachChild: function(fn) {
        var children = this._children;
        for(var i=0, j=children.length; i<j; i++) {
            var retVal = fn(children[i]);
            if (retVal === false) return false;
        }
        return true;
    },
    withEachDescendant: function(fn) {
        this.withEachChild(function(child) {
            if (fn(child) === false) return false;
            child.withEachDescendant(fn);
        });
        return true;
    },
    withEachDescendantInDispatchTier: function(fn) {
        var that = this;
        this.withEachChild(function(child) {
            fn(child);
            var testContext = new Splunk.Context();
            var search = new Sideview.SplunkSearch();
            search.sid = 1234;
            testContext.set("search",search);
            var downstreamSearch = child.getModifiedContext(testContext).get("search");

            if (!downstreamSearch.isJobDispatched()) {
                //console.log(that.moduleId + " withEachDescendantInDispatchTier - child module " + child.moduleId + " is a dispatch point so we have called the callback on him but we're not recursing down from here");
                return false;
            }
            child.withEachDescendantInDispatchTier(fn);
        });
        return true;
    },
    getRootAncestor: function() {
        var pointer = this, retVal = null;
        while(pointer) {
            retVal = pointer;
            pointer = pointer.parent;
        }
        return retVal;
    },
    getAncestors: function() {
        var pointer = this.parent, retVal = [];
        while(pointer) {
            retVal.unshift(pointer);
            pointer = pointer.parent;
        }
        return retVal;
    },
    getDescendants: function() {
        var descendants=this._children.slice();
        for(var i=0; i<descendants.length; i++) {
            descendants = descendants.concat(descendants[i]._children);
        }
        return descendants;
    },
    addChild: function(child) {
        if (child.parent) {
            throw("tried to add " + child.moduleId + " as a child but it already has a parent of " + child.parent.moduleId);
        }
        child.parent = this;
        this._children.push(child);
    },

    removeChild : function(child) {
        var newFamily = [];
        for (var i=0,len=this._children.length; i<len;i++) {
            if (child == this._children[i]) {
                this._children[i].parent = null;
            } else {
                newFamily.push(this._children[i]);
            }
        }
        this._children = newFamily;
    },

    


    /************
      VISIBILITY
     ***********/
     

    show: function(reason) {
        reason = reason || "global";
        if (this._invisibilityModes.hasOwnProperty(reason)) {
            delete this._invisibilityModes[reason];
        }
        this._changeVisibility();
    },

    hide: function(reason) {
        reason = reason || "global";
        this._invisibilityModes[reason] = 1;
        this._changeVisibility();
    },

    showDescendants: function(reason) {
        for (var i=0; i<this._children.length;i++) {
            this._children[i].show(reason);
            this._children[i].showDescendants(reason);
        }
    },


    hideDescendants: function(reason) {
        for (var i=0,len=this._children.length;i<len;i++) {
            this._children[i].hide(reason);
            this._children[i].hideDescendants(reason);
        }
    },

    _changeVisibility: function() {
        var showMe = true;
        for (var mode in this._invisibilityModes) {
            if (this._invisibilityModes.hasOwnProperty(mode)) {
                showMe = false;
            }
        }
        if (showMe) this.container.show();
        else this.container.hide();
    },

    
    /************
      PARAMS
     ***********/
    getParam: function(key, defaultValue) {
        if (!key) {
            throw("no key passed to getParam");
        }
        if (this._params.hasOwnProperty(key)) {
            return this._params[key];
        }
        return null;
    },

    setParam: function(k,v) {
        this._params[k] = v;
    },


    /************
      MISC
     ***********/
    displayInlineErrorMessage: function(error) {
        var errorDiv = $("div.error", this.container);
        if (errorDiv.length == 0 ) {
            errorDiv = $("<div>")
                .addClass("error")
                .appendTo(this.container);
        }
        errorDiv.text(message);
    },

    ensureFreshContexts: function() {},
    setChildContextFreshness: function() {}

});

Sideview.Module.ALWAYS_REQUIRE = 1;
Sideview.Module.NEVER_ALLOW = -1;
Sideview.Module.CANCEL = -1;
Sideview.Module.DEFER = 0;
Sideview.Module.CONTINUE = 1;

Splunk.Module = Sideview.Module
Splunk.Module.DispatchingModule = Sideview.Module


